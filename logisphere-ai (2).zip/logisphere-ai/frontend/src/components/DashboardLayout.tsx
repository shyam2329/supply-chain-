import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { getStoredUser, logout } from "@api/auth";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: "📊" },
  { to: "/inventory", label: "Inventory", icon: "📦" },
  { to: "/shipments", label: "Shipments", icon: "🚚" },
  { to: "/warehouses", label: "Warehouses", icon: "🏭" },
  { to: "/suppliers", label: "Suppliers", icon: "🤝" },
  { to: "/analytics", label: "Analytics", icon: "📈" },
];

export default function DashboardLayout() {
  const navigate = useNavigate();
  const user = getStoredUser();

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <div className="flex h-screen bg-logisphere-bg text-gray-100">
      <aside className="w-60 shrink-0 border-r border-white/10 bg-logisphere-panel p-4 flex flex-col">
        <div className="text-lg font-bold mb-8 tracking-tight">LogiSphere AI</div>
        <nav className="flex-1 space-y-1">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors ${
                  isActive ? "bg-logisphere-accent/20 text-logisphere-accent" : "hover:bg-white/5"
                }`
              }
            >
              <span>{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>
        <NavLink
          to="/digital-twin"
          className={({ isActive }) =>
            `flex items-center gap-2 px-3 py-2 rounded-md text-sm font-semibold border border-logisphere-accent/40 mb-4 ${
              isActive ? "bg-logisphere-accent/20 text-logisphere-accent" : "text-logisphere-accent hover:bg-logisphere-accent/10"
            }`
          }
        >
          🌐 Digital Twin ⭐
        </NavLink>
        <div className="border-t border-white/10 pt-3 flex items-center justify-between">
          <div className="text-xs text-gray-400 truncate">
            {user?.name ?? "Signed in"}
            <div className="text-gray-600 capitalize">{user?.role?.replace("_", " ")}</div>
          </div>
          <button
            onClick={handleLogout}
            className="text-xs text-gray-500 hover:text-logisphere-danger transition-colors"
          >
            Logout
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto p-6">
        <Outlet />
      </main>
    </div>
  );
}
