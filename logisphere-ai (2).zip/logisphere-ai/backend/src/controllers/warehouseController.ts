import { Response } from "express";
import { pool } from "@config/db";
import { AuthedRequest } from "@middleware/auth";

export async function listWarehouses(_req: AuthedRequest, res: Response) {
  const result = await pool.query(
    `SELECT
       w.*,
       COALESCE(inv.used_units, 0) AS used_units,
       COALESCE(active.active_shipments, 0) AS active_shipments
     FROM warehouses w
     LEFT JOIN (
       SELECT warehouse_id, SUM(quantity) AS used_units
       FROM inventory
       GROUP BY warehouse_id
     ) inv ON inv.warehouse_id = w.id
     LEFT JOIN (
       SELECT origin_warehouse_id, COUNT(*) AS active_shipments
       FROM shipments
       WHERE status IN ('dispatched', 'in_transit', 'delayed')
       GROUP BY origin_warehouse_id
     ) active ON active.origin_warehouse_id = w.id
     ORDER BY w.name`
  );
  res.json(result.rows);
}

export async function getWarehouse(req: AuthedRequest, res: Response) {
  const { id } = req.params;
  const result = await pool.query(`SELECT * FROM warehouses WHERE id = $1`, [id]);
  if (result.rowCount === 0) {
    return res.status(404).json({ error: "Warehouse not found" });
  }
  res.json(result.rows[0]);
}
