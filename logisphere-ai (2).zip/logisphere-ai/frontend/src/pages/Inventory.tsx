import { useEffect, useState } from "react";
import { fetchInventory, adjustStock, InventoryRow } from "@api/inventory";
import StatusBadge from "@components/StatusBadge";

export default function Inventory() {
  const [rows, setRows] = useState<InventoryRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  function load() {
    setLoading(true);
    setError(null);
    fetchInventory()
      .then(setRows)
      .catch(() => setError("Failed to load inventory."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleAdjust(id: string, delta: number) {
    setBusyId(id);
    try {
      await adjustStock(id, delta, delta > 0 ? "Manual stock in" : "Manual stock out");
      load();
    } catch {
      setError("Stock adjustment failed.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Inventory</h1>
        <span className="text-xs text-gray-500">{rows.length} product{rows.length === 1 ? "" : "s"}</span>
      </div>

      {loading && <p className="text-sm text-gray-500">Loading inventory...</p>}
      {error && <p className="text-sm text-logisphere-danger">{error}</p>}

      {!loading && !error && rows.length === 0 && (
        <p className="text-sm text-gray-500">No inventory records yet.</p>
      )}

      {!loading && !error && rows.length > 0 && (
        <div className="bg-logisphere-panel border border-white/10 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b border-white/10">
                <th className="px-4 py-3 font-medium">Product</th>
                <th className="px-4 py-3 font-medium">SKU</th>
                <th className="px-4 py-3 font-medium">Category</th>
                <th className="px-4 py-3 font-medium">Warehouse</th>
                <th className="px-4 py-3 font-medium">Quantity</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium text-right">Stock In / Out</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-white/5 last:border-0">
                  <td className="px-4 py-3">{r.product_name}</td>
                  <td className="px-4 py-3 text-gray-400">{r.sku}</td>
                  <td className="px-4 py-3 text-gray-400">{r.category ?? "—"}</td>
                  <td className="px-4 py-3 text-gray-400">{r.warehouse_name}</td>
                  <td className="px-4 py-3">
                    {r.quantity}
                    <span className="text-gray-600"> / min {r.low_stock_threshold}</span>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={r.status} />
                  </td>
                  <td className="px-4 py-3 text-right space-x-2">
                    <button
                      disabled={busyId === r.id}
                      onClick={() => handleAdjust(r.id, 10)}
                      className="px-2 py-1 rounded-md text-xs border border-white/10 bg-white/5 hover:bg-white/10 disabled:opacity-40"
                    >
                      +10
                    </button>
                    <button
                      disabled={busyId === r.id || r.quantity === 0}
                      onClick={() => handleAdjust(r.id, -10)}
                      className="px-2 py-1 rounded-md text-xs border border-white/10 bg-white/5 hover:bg-white/10 disabled:opacity-40"
                    >
                      -10
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
