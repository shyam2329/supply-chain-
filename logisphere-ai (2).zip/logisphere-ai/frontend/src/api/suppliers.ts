import { apiClient } from "./client";

export interface SupplierRow {
  id: string;
  name: string;
  contact_email: string | null;
  contact_phone: string | null;
  on_time_rate: number;
  performance_score: number;
  product_count: number;
}

export async function fetchSuppliers(): Promise<SupplierRow[]> {
  const { data } = await apiClient.get<SupplierRow[]>("/suppliers");
  return data;
}
