import { apiClient } from "./client";

export interface InventoryRow {
  id: string;
  sku: string;
  product_name: string;
  category: string | null;
  warehouse_id: string;
  warehouse_name: string;
  quantity: number;
  low_stock_threshold: number;
  status: "good" | "low_stock" | "out_of_stock";
  updated_at: string;
}

export async function fetchInventory(): Promise<InventoryRow[]> {
  const { data } = await apiClient.get<InventoryRow[]>("/inventory");
  return data;
}

export async function adjustStock(id: string, change_qty: number, reason?: string) {
  const { data } = await apiClient.patch<InventoryRow>(`/inventory/${id}/adjust`, {
    change_qty,
    reason,
  });
  return data;
}
