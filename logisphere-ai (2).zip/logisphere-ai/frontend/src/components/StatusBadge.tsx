const COLORS: Record<string, string> = {
  pending: "bg-gray-500/20 text-gray-300",
  dispatched: "bg-blue-500/20 text-blue-300",
  in_transit: "bg-logisphere-accent/20 text-logisphere-accent",
  delayed: "bg-logisphere-danger/20 text-logisphere-danger",
  delivered: "bg-blue-500/20 text-blue-300",
  returned: "bg-gray-500/20 text-gray-400",
  cancelled: "bg-gray-700/30 text-gray-500",
  good: "bg-logisphere-accent/20 text-logisphere-accent",
  low_stock: "bg-logisphere-warn/20 text-logisphere-warn",
  out_of_stock: "bg-logisphere-danger/20 text-logisphere-danger",
};

export default function StatusBadge({ status }: { status: string }) {
  const cls = COLORS[status] ?? "bg-white/10 text-gray-300";
  return (
    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium capitalize ${cls}`}>
      {status.replace(/_/g, " ")}
    </span>
  );
}
