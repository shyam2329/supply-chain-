import { apiClient } from "./client";
import { UserRole } from "@apptypes/index";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export async function login(email: string, password: string) {
  const { data } = await apiClient.post<{ token: string; user: AuthUser }>(
    "/auth/login",
    { email, password }
  );
  localStorage.setItem("logisphere_token", data.token);
  localStorage.setItem("logisphere_user", JSON.stringify(data.user));
  return data;
}

export function logout() {
  localStorage.removeItem("logisphere_token");
  localStorage.removeItem("logisphere_user");
}

export function getStoredUser(): AuthUser | null {
  const raw = localStorage.getItem("logisphere_user");
  return raw ? JSON.parse(raw) : null;
}
