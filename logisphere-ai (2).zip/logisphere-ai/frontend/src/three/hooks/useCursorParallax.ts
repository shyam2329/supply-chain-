import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

/**
 * Subtly tilts/pans the camera toward the cursor position using damped
 * lerp interpolation. Deliberately restrained — this is an "inspector"
 * feel (Apple/Tesla-style product page), not free camera movement.
 */
export function useCursorParallax(opts?: {
  strength?: number;
  damping?: number;
  lookAt?: [number, number, number];
}) {
  const strength = opts?.strength ?? 1.2;
  const damping = opts?.damping ?? 0.04;
  const lookAtTarget = opts?.lookAt ?? [0, 0, 0];

  const { camera } = useThree();
  const mouse = useRef({ x: 0, y: 0 });
  const basePosition = useRef(camera.position.clone());
  const target = useRef(new THREE.Vector3());

  useEffect(() => {
    basePosition.current = camera.position.clone();

    function handleMove(e: MouseEvent) {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    }

    window.addEventListener("mousemove", handleMove);
    return () => window.removeEventListener("mousemove", handleMove);
  }, [camera]);

  useFrame(() => {
    target.current.set(
      basePosition.current.x + mouse.current.x * strength,
      basePosition.current.y - mouse.current.y * strength * 0.5,
      basePosition.current.z
    );
    camera.position.lerp(target.current, damping);
    camera.lookAt(...lookAtTarget);
  });
}
