import { Text } from "@react-three/drei";
import { DESTINATION_POINT } from "@three/layout";

export default function Destination({ label }: { label: string }) {
  return (
    <group position={[DESTINATION_POINT[0], 0, DESTINATION_POINT[2]]}>
      <mesh position={[0, 0.4, 0]}>
        <coneGeometry args={[0.18, 0.5, 4]} />
        <meshStandardMaterial color="#4C8DFF" emissive="#4C8DFF" emissiveIntensity={0.3} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
        <circleGeometry args={[0.9, 32]} />
        <meshStandardMaterial color="#161B26" />
      </mesh>
      <Text
        position={[0, 0.9, 0]}
        fontSize={0.22}
        color="#9CA3AF"
        anchorX="center"
        anchorY="middle"
        maxWidth={2}
      >
        {label}
      </Text>
    </group>
  );
}
