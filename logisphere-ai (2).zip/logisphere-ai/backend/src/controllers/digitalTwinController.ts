import { Response } from "express";
import { pool } from "@config/db";
import { AuthedRequest } from "@middleware/auth";

/**
 * Convenience aggregate for the Digital Twin: warehouses (with capacity/
 * bay stats) + shipments in one round trip. The frontend's
 * useDigitalTwinState hook currently composes the same data from
 * /api/warehouses + /api/shipments (already working end-to-end with live
 * Socket.IO updates), so this endpoint is additive — useful for other
 * consumers (e.g. a future mobile client) without touching that flow.
 */
export async function getDigitalTwinState(_req: AuthedRequest, res: Response) {
  const [warehouses, shipments] = await Promise.all([
    pool.query(`
      SELECT
        w.*,
        COALESCE(inv.used_units, 0) AS used_units,
        COALESCE(active.active_shipments, 0) AS active_shipments
      FROM warehouses w
      LEFT JOIN (
        SELECT warehouse_id, SUM(quantity) AS used_units
        FROM inventory
        GROUP BY warehouse_id
      ) inv ON inv.warehouse_id = w.id
      LEFT JOIN (
        SELECT origin_warehouse_id, COUNT(*) AS active_shipments
        FROM shipments
        WHERE status IN ('dispatched', 'in_transit', 'delayed')
        GROUP BY origin_warehouse_id
      ) active ON active.origin_warehouse_id = w.id
      ORDER BY w.name
    `),
    pool.query(`
      SELECT s.*, ow.name AS origin_name, dw.name AS destination_name
      FROM shipments s
      LEFT JOIN warehouses ow ON ow.id = s.origin_warehouse_id
      LEFT JOIN warehouses dw ON dw.id = s.destination_warehouse_id
      ORDER BY s.updated_at DESC
    `),
  ]);

  res.json({ warehouses: warehouses.rows, shipments: shipments.rows });
}
