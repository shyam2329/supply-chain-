import { useEffect, useState } from "react";
import { fetchSuppliers, SupplierRow } from "@api/suppliers";

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState<SupplierRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchSuppliers()
      .then(setSuppliers)
      .catch(() => setError("Failed to load suppliers."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Suppliers</h1>

      {loading && <p className="text-sm text-gray-500">Loading suppliers...</p>}
      {error && <p className="text-sm text-logisphere-danger">{error}</p>}
      {!loading && !error && suppliers.length === 0 && (
        <p className="text-sm text-gray-500">No suppliers yet.</p>
      )}

      {!loading && !error && suppliers.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {suppliers.map((s) => {
            const scorePct = Math.min(100, (s.performance_score / 10) * 100);
            const scoreColor =
              s.performance_score >= 8.5
                ? "text-logisphere-accent"
                : s.performance_score >= 6
                ? "text-logisphere-warn"
                : "text-logisphere-danger";
            return (
              <div
                key={s.id}
                className="bg-logisphere-panel border border-white/10 rounded-xl p-4 space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-semibold">{s.name}</div>
                    <div className="text-xs text-gray-500">{s.contact_email ?? "No contact on file"}</div>
                  </div>
                  <div className={`text-lg font-bold ${scoreColor}`}>
                    ⭐ {Number(s.performance_score).toFixed(1)}
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>On-time delivery</span>
                    <span>{Number(s.on_time_rate).toFixed(0)}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full bg-logisphere-accent"
                      style={{ width: `${s.on_time_rate}%` }}
                    />
                  </div>
                </div>

                <div className="text-xs text-gray-500">
                  {s.product_count} product{s.product_count === 1 ? "" : "s"} supplied
                </div>

                <div className="h-1 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className={`h-full ${
                      s.performance_score >= 8.5
                        ? "bg-logisphere-accent"
                        : s.performance_score >= 6
                        ? "bg-logisphere-warn"
                        : "bg-logisphere-danger"
                    }`}
                    style={{ width: `${scorePct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
