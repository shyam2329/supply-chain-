import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchDashboardSummary, DashboardSummary } from "@api/dashboard";

export default function Dashboard() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchDashboardSummary()
      .then(setSummary)
      .catch(() => setError("Failed to load dashboard data."))
      .finally(() => setLoading(false));
  }, []);

  const stats = summary
    ? [
        { label: "Total Shipments", value: summary.totalShipments },
        { label: "Active Shipments", value: summary.activeShipments },
        { label: "Delayed Shipments", value: summary.delayedShipments, danger: summary.delayedShipments > 0 },
        { label: "Warehouse Capacity", value: `${summary.warehouseCapacity}%` },
        { label: "Fleet Availability", value: `${summary.fleetAvailability} in garage` },
        { label: "Supplier Performance", value: `${summary.supplierPerformance}% avg on-time` },
        { label: "Delivery Performance", value: summary.deliveryPerformance },
        {
          label: "AI Insights",
          value: summary.aiInsights.length > 0 ? `${summary.aiInsights.length} at risk` : "All clear",
        },
      ]
    : [];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <Link
          to="/digital-twin"
          className="flex items-center gap-2 px-4 py-2 rounded-md text-sm font-semibold bg-logisphere-accent text-black hover:opacity-90 transition-opacity"
        >
          🌐 OPEN DIGITAL TWIN →
        </Link>
      </div>

      {loading && <p className="text-sm text-gray-500">Loading dashboard...</p>}
      {error && <p className="text-sm text-logisphere-danger">{error}</p>}

      {!loading && !error && summary && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((s) => (
              <div key={s.label} className="bg-logisphere-panel border border-white/10 rounded-xl p-4">
                <div className="text-sm text-gray-400">{s.label}</div>
                <div className={`text-2xl font-bold ${s.danger ? "text-logisphere-danger" : ""}`}>
                  {s.value}
                </div>
              </div>
            ))}
          </div>

          {summary.aiInsights.length > 0 && (
            <div className="mt-6 bg-logisphere-accent/10 border border-logisphere-accent/30 rounded-xl p-4">
              <div className="text-xs text-logisphere-accent font-semibold uppercase tracking-wide mb-2">
                🤖 AI Insights
              </div>
              <ul className="space-y-1 text-sm text-gray-300">
                {summary.aiInsights.map((insight, i) => (
                  <li key={i}>• {insight}</li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}

      <p className="text-xs text-gray-500 mt-6">
        Live shipment and warehouse data from PostgreSQL. Click "Open Digital Twin" to see and
        control the 3D logistics visualization in real time.
      </p>
    </div>
  );
}
