import { useMemo } from "react";
import { useDigitalTwinState } from "@hooks/useDigitalTwinState";
import DigitalTwinScene from "@components/digitalTwin/DigitalTwinScene";
import TruckInspector from "@components/digitalTwin/TruckInspector";
import TwinControls from "@components/digitalTwin/TwinControls";
import SimulationPanel from "@components/digitalTwin/SimulationPanel";

export default function DigitalTwin() {
  const {
    shipments,
    warehouses,
    loading,
    error,
    connected,
    reload,
    applyShipmentUpdate,
    selectedShipmentId,
    setSelectedShipmentId,
    selectedShipment,
    hoveredId,
    setHoveredId,
  } = useDigitalTwinState();

  // Focus the scene on whichever warehouse actually has shipments — falls
  // back to the first warehouse if none do yet.
  const primaryWarehouse = useMemo(() => {
    if (warehouses.length === 0) return null;
    const originId = shipments[0]?.origin_warehouse_id;
    return warehouses.find((w) => w.id === originId) ?? warehouses[0];
  }, [warehouses, shipments]);

  const warehouseShipments = useMemo(
    () => shipments.filter((s) => s.origin_warehouse_id === primaryWarehouse?.id),
    [shipments, primaryWarehouse]
  );

  return (
    <div className="-m-6 h-[85vh] flex flex-col">
      <header className="flex items-center justify-between px-6 py-3 border-b border-white/10 bg-logisphere-panel/60">
        <div>
          <h1 className="text-lg font-bold">🌐 Digital Twin</h1>
          <p className="text-xs text-gray-500">
            {primaryWarehouse ? primaryWarehouse.name : "Loading warehouse..."} — live shipment
            visualization
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <button
            onClick={reload}
            className="px-2 py-1 rounded-md border border-white/10 bg-white/5 hover:bg-white/10 text-gray-300"
          >
            ⟳ Refresh
          </button>
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${connected ? "bg-logisphere-accent" : "bg-logisphere-danger"}`}
            />
            {connected ? "Live" : "Disconnected"}
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 relative">
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center text-gray-500 text-sm">
              Loading Digital Twin...
            </div>
          )}
          {error && (
            <div className="absolute inset-0 flex items-center justify-center text-logisphere-danger text-sm px-8 text-center">
              {error}
            </div>
          )}
          {!loading && !error && primaryWarehouse && (
            <DigitalTwinScene
              warehouse={primaryWarehouse}
              shipments={warehouseShipments}
              hoveredId={hoveredId}
              selectedId={selectedShipmentId}
              onHover={setHoveredId}
              onSelect={setSelectedShipmentId}
            />
          )}
        </div>

        <aside className="w-80 shrink-0 border-l border-white/10 bg-logisphere-panel/60 overflow-y-auto flex flex-col">
          <TruckInspector shipment={selectedShipment} onClose={() => setSelectedShipmentId(null)} />
          <TwinControls shipment={selectedShipment} onUpdated={applyShipmentUpdate} />
          <SimulationPanel shipment={selectedShipment} onUpdated={applyShipmentUpdate} />
        </aside>
      </div>
    </div>
  );
}
