import { useCallback, useEffect, useMemo, useState } from "react";
import { fetchDigitalTwinState } from "@api/digitalTwin";
import { WarehouseWithStats } from "@api/warehouses";
import { useShipmentSocket } from "@hooks/useShipmentSocket";
import { Shipment } from "@apptypes/index";

export function useDigitalTwinState() {
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [warehouses, setWarehouses] = useState<WarehouseWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedShipmentId, setSelectedShipmentId] = useState<string | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const { lastEvent, connected } = useShipmentSocket();

  // Initial load (and manual refresh) — uses the single /api/digital-twin
  // aggregate endpoint rather than two separate calls. This should be
  // called sparingly: after the first mount, prefer applyShipmentUpdate()
  // (below) so a stale GET response can't race with and overwrite a
  // newer Socket.IO event — see the race condition note there.
  const reload = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const state = await fetchDigitalTwinState();
      setShipments(state.shipments);
      setWarehouses(state.warehouses);
    } catch (err) {
      setError("Failed to load Digital Twin data. Is the backend running and are you logged in?");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  // Merge live Redis-sourced events into local shipment state so the 3D
  // scene reacts immediately without waiting for a refetch.
  useEffect(() => {
    if (!lastEvent) return;
    setShipments((prev) =>
      prev.map((s) =>
        s.id === lastEvent.shipmentId
          ? {
              ...s,
              status: lastEvent.status,
              route_progress: lastEvent.routeProgress ?? s.route_progress,
              assigned_bay: lastEvent.assignedBay ?? s.assigned_bay,
              delay_reason: lastEvent.delayReason ?? s.delay_reason,
              updated_at: lastEvent.timestamp,
            }
          : s
      )
    );
  }, [lastEvent]);

  /**
   * Merges a single shipment (e.g. a PATCH response) directly into local
   * state instead of triggering a full reload(). This is what
   * TwinControls/SimulationPanel call after a successful action.
   *
   * Why this matters: calling reload() right after a PATCH kicks off a
   * GET that can resolve AFTER a Socket.IO event for the same change has
   * already arrived and updated state — the stale GET response would
   * then overwrite the newer real-time state. Merging the PATCH's own
   * response (which reflects the exact write that just happened)
   * sidesteps that race entirely; the later Socket.IO event for the same
   * change is just a same-data no-op merge when it arrives.
   */
  const applyShipmentUpdate = useCallback((updated: Shipment) => {
    setShipments((prev) => prev.map((s) => (s.id === updated.id ? { ...s, ...updated } : s)));
  }, []);

  // Deterministically assign a garage bay to pending shipments that don't
  // already have one, so the garage always renders a sensible layout even
  // if the backend hasn't set assigned_bay explicitly.
  const shipmentsWithBays = useMemo(() => {
    const bayCounters: Record<string, number> = {};
    return shipments.map((s) => {
      if (s.status !== "pending" || s.assigned_bay != null || !s.origin_warehouse_id) {
        return s;
      }
      const wid = s.origin_warehouse_id;
      bayCounters[wid] = (bayCounters[wid] ?? 0) + 1;
      return { ...s, assigned_bay: bayCounters[wid] };
    });
  }, [shipments]);

  const selectedShipment = useMemo(
    () => shipmentsWithBays.find((s) => s.id === selectedShipmentId) ?? null,
    [shipmentsWithBays, selectedShipmentId]
  );

  return {
    shipments: shipmentsWithBays,
    warehouses,
    loading,
    error,
    connected,
    reload,
    applyShipmentUpdate,
    selectedShipmentId,
    setSelectedShipmentId,
    selectedShipment,
    hoveredId,
    setHoveredId,
  };
}
