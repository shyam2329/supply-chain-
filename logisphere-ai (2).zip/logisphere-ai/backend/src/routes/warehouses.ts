import { Router } from "express";
import { requireAuth } from "@middleware/auth";
import { asyncHandler } from "@middleware/asyncHandler";
import { listWarehouses, getWarehouse } from "@controllers/warehouseController";

const router = Router();

router.get("/", requireAuth, asyncHandler(listWarehouses));
router.get("/:id", requireAuth, asyncHandler(getWarehouse));

export default router;
