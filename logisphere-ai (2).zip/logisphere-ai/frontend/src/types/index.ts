export type ShipmentStatus =
  | "pending"
  | "packed"
  | "dispatched"
  | "in_transit"
  | "delayed"
  | "delivered"
  | "returned"
  | "cancelled";

export interface Shipment {
  id: string;
  reference_code: string;
  origin_warehouse_id: string | null;
  destination_warehouse_id: string | null;
  destination_label: string | null;
  product_id?: string | null;
  quantity: number;
  status: ShipmentStatus;
  assigned_bay: number | null;
  route_progress: number; // 0-100, drives 3D truck position along its route
  delay_reason: string | null;
  updated_at: string;
  /** Present on PATCH responses only: false means the DB write succeeded
   * but the Redis publish (and therefore the Socket.IO broadcast to other
   * viewers) may not have gone out. */
  realtimeDelivered?: boolean;
}

export interface ShipmentUpdateEvent {
  shipmentId: string;
  referenceCode: string;
  status: ShipmentStatus;
  routeProgress: number;
  assignedBay: number | null;
  delayReason: string | null;
  timestamp: string;
}

export interface Warehouse {
  id: string;
  name: string;
  city: string;
  latitude: number | null;
  longitude: number | null;
  capacity_units: number;
  garage_bays: number;
}

export type UserRole = "admin" | "warehouse_manager" | "supplier";
