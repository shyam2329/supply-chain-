import { Canvas } from "@react-three/fiber";
import { useMemo } from "react";
import { Shipment } from "@apptypes/index";
import { WarehouseWithStats } from "@api/warehouses";
import { useCursorParallax } from "@three/hooks/useCursorParallax";
import WarehouseNode from "./WarehouseNode";
import Garage from "./Garage";
import Truck from "./Truck";
import Route from "./Route";
import RoutePulse from "./RoutePulse";
import Destination from "./Destination";

interface SceneContentProps {
  warehouse: WarehouseWithStats;
  shipments: Shipment[];
  hoveredId: string | null;
  selectedId: string | null;
  onHover: (id: string | null) => void;
  onSelect: (id: string) => void;
}

function SceneContent({
  warehouse,
  shipments,
  hoveredId,
  selectedId,
  onHover,
  onSelect,
}: SceneContentProps) {
  useCursorParallax({ strength: 1.6, damping: 0.05, lookAt: [0, 1, 10] });

  const activeShipments = useMemo(
    () => shipments.filter((s) => s.status !== "pending" && s.status !== "cancelled"),
    [shipments]
  );
  const delayedCount = shipments.filter((s) => s.status === "delayed").length;
  const destinationLabel =
    activeShipments[0]?.destination_label ?? "Customer Delivery Zone";

  return (
    <>
      <ambientLight intensity={0.55} />
      <directionalLight position={[6, 10, 4]} intensity={1.1} castShadow />
      <fog attach="fog" args={["#0B0F19", 14, 32]} />

      {/* ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 8]} receiveShadow>
        <planeGeometry args={[40, 40]} />
        <meshStandardMaterial color="#0E121C" />
      </mesh>

      <WarehouseNode
        warehouse={warehouse}
        isHovered={hoveredId === warehouse.id}
        onHover={onHover}
      />

      <Garage totalBays={warehouse.garage_bays} shipments={shipments} />

      <Route warehouse={warehouse} destinationLabel={destinationLabel} delayedCount={delayedCount} />
      <Destination label={destinationLabel} />

      {activeShipments.map((s) => (
        <RoutePulse key={`pulse-${s.id}`} shipment={s} />
      ))}

      {shipments.map((s) => (
        <Truck
          key={s.id}
          shipment={s}
          totalBays={warehouse.garage_bays}
          isSelected={selectedId === s.id}
          isHovered={hoveredId === s.id}
          onHover={onHover}
          onSelect={onSelect}
        />
      ))}
    </>
  );
}

interface DigitalTwinSceneProps {
  warehouse: WarehouseWithStats;
  shipments: Shipment[];
  hoveredId: string | null;
  selectedId: string | null;
  onHover: (id: string | null) => void;
  onSelect: (id: string) => void;
}

export default function DigitalTwinScene(props: DigitalTwinSceneProps) {
  return (
    <Canvas
      shadows
      camera={{ position: [11, 8, -3], fov: 40 }}
      className="!bg-logisphere-bg"
    >
      <SceneContent {...props} />
    </Canvas>
  );
}
