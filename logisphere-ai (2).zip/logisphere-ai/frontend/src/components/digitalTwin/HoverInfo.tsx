import { Html } from "@react-three/drei";
import { ReactNode } from "react";

export default function HoverInfo({ children }: { children: ReactNode }) {
  return (
    <Html
      position={[0, 1.1, 0]}
      center
      distanceFactor={8}
      style={{ pointerEvents: "none" }}
    >
      <div className="min-w-[160px] bg-[#121826]/95 border border-white/10 rounded-lg px-3 py-2 text-[11px] leading-tight text-gray-100 shadow-xl backdrop-blur-sm">
        {children}
      </div>
    </Html>
  );
}
