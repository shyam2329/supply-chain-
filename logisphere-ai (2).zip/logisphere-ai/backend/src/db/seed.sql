-- LogiSphere AI — Seed Data
-- Uses fixed UUIDs so the Digital Twin, garage bays, and routes have
-- consistent, referenceable data on first run.
-- Demo login: admin@logisphere.ai / password123

INSERT INTO users (id, name, email, password_hash, role) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Admin User', 'admin@logisphere.ai',
   '$2b$10$fOcSpfrmbxZJn0YydgRWkeBpzi7A8Yvtks5jxj4Dp8xN1ht7OD4CW', 'admin'),
  ('00000000-0000-0000-0000-000000000002', 'Priya Warehouse Mgr', 'priya@logisphere.ai',
   '$2b$10$fOcSpfrmbxZJn0YydgRWkeBpzi7A8Yvtks5jxj4Dp8xN1ht7OD4CW', 'warehouse_manager');

INSERT INTO warehouses (id, name, city, latitude, longitude, capacity_units, garage_bays, manager_id) VALUES
  ('10000000-0000-0000-0000-000000000001', 'Chennai Hub', 'Chennai', 13.0827, 80.2707, 20000, 4, '00000000-0000-0000-0000-000000000002'),
  ('10000000-0000-0000-0000-000000000002', 'Bangalore Hub', 'Bangalore', 12.9716, 77.5946, 15000, 4, NULL),
  ('10000000-0000-0000-0000-000000000003', 'Mumbai Hub', 'Mumbai', 19.0760, 72.8777, 18000, 4, NULL);

INSERT INTO suppliers (id, name, contact_email, on_time_rate, performance_score) VALUES
  ('20000000-0000-0000-0000-000000000001', 'ABC Electronics', 'contact@abcelectronics.com', 95.00, 9.5),
  ('20000000-0000-0000-0000-000000000002', 'XYZ Supplies', 'sales@xyzsupplies.com', 70.00, 7.0);

INSERT INTO products (id, sku, name, category, unit_price, supplier_id) VALUES
  ('30000000-0000-0000-0000-000000000001', 'SKU-LAP-001', 'Laptop', 'Electronics', 55000, '20000000-0000-0000-0000-000000000001'),
  ('30000000-0000-0000-0000-000000000002', 'SKU-MOB-001', 'Mobile Phone', 'Electronics', 18000, '20000000-0000-0000-0000-000000000001'),
  ('30000000-0000-0000-0000-000000000003', 'SKU-MON-001', 'Monitor', 'Electronics', 12000, '20000000-0000-0000-0000-000000000002');

INSERT INTO inventory (product_id, warehouse_id, quantity, low_stock_threshold, status) VALUES
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 250, 30, 'good'),
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000002', 12, 20, 'low_stock'),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000003', 0, 15, 'out_of_stock');

-- Shipments: this is what the Digital Twin renders.
-- assigned_bay is only meaningful while status = 'pending' (truck parked in garage).
-- route_progress (0-100) drives the truck's position along its road once dispatched.
INSERT INTO shipments (id, reference_code, origin_warehouse_id, destination_warehouse_id, destination_label, product_id, quantity, status, assigned_bay, route_progress) VALUES
  ('40000000-0000-0000-0000-000000000001', 'SHP-1001', '10000000-0000-0000-0000-000000000001', NULL, 'Customer — T. Nagar, Chennai', '30000000-0000-0000-0000-000000000001', 10, 'pending', 1, 0),
  ('40000000-0000-0000-0000-000000000002', 'SHP-1002', '10000000-0000-0000-0000-000000000001', NULL, 'Customer — Anna Nagar, Chennai', '30000000-0000-0000-0000-000000000002', 5, 'in_transit', NULL, 45),
  ('40000000-0000-0000-0000-000000000003', 'SHP-1003', '10000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000002', 'Bangalore Hub', '30000000-0000-0000-0000-000000000003', 20, 'delayed', NULL, 60),
  ('40000000-0000-0000-0000-000000000004', 'SHP-1004', '10000000-0000-0000-0000-000000000001', NULL, 'Customer — Velachery, Chennai', '30000000-0000-0000-0000-000000000001', 2, 'pending', 2, 0),
  ('40000000-0000-0000-0000-000000000005', 'SHP-1005', '10000000-0000-0000-0000-000000000001', NULL, 'Customer — Adyar, Chennai', '30000000-0000-0000-0000-000000000002', 8, 'delivered', NULL, 100),
  ('40000000-0000-0000-0000-000000000006', 'SHP-1006', '10000000-0000-0000-0000-000000000001', NULL, 'Customer — Nungambakkam, Chennai', '30000000-0000-0000-0000-000000000003', 4, 'returned', 3, 0);

INSERT INTO shipment_events (shipment_id, status, note) VALUES
  ('40000000-0000-0000-0000-000000000001', 'pending', 'Order created'),
  ('40000000-0000-0000-0000-000000000002', 'pending', 'Order created'),
  ('40000000-0000-0000-0000-000000000002', 'dispatched', 'Left Chennai Hub'),
  ('40000000-0000-0000-0000-000000000002', 'in_transit', 'En route'),
  ('40000000-0000-0000-0000-000000000003', 'pending', 'Order created'),
  ('40000000-0000-0000-0000-000000000003', 'dispatched', 'Left Chennai Hub'),
  ('40000000-0000-0000-0000-000000000003', 'in_transit', 'En route'),
  ('40000000-0000-0000-0000-000000000003', 'delayed', 'Road congestion near toll plaza'),
  ('40000000-0000-0000-0000-000000000004', 'pending', 'Order created');
INSERT INTO shipment_events (shipment_id, status, note) VALUES
  ('40000000-0000-0000-0000-000000000005', 'pending', 'Order created'),
  ('40000000-0000-0000-0000-000000000005', 'dispatched', 'Left Chennai Hub'),
  ('40000000-0000-0000-0000-000000000005', 'in_transit', 'En route'),
  ('40000000-0000-0000-0000-000000000005', 'delivered', 'Delivered to customer'),
  ('40000000-0000-0000-0000-000000000006', 'pending', 'Order created'),
  ('40000000-0000-0000-0000-000000000006', 'dispatched', 'Left Chennai Hub'),
  ('40000000-0000-0000-0000-000000000006', 'in_transit', 'En route'),
  ('40000000-0000-0000-0000-000000000006', 'delivered', 'Delivered to customer'),
  ('40000000-0000-0000-0000-000000000006', 'returned', 'Returned to Chennai Hub');
