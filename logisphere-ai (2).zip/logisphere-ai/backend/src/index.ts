import "dotenv/config";
import express from "express";
import cors from "cors";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";

import shipmentRoutes from "@routes/shipments";
import warehouseRoutes from "@routes/warehouses";
import authRoutes from "@routes/auth";
import simulationRoutes from "@routes/simulation";
import dashboardRoutes from "@routes/dashboard";
import inventoryRoutes from "@routes/inventory";
import supplierRoutes from "@routes/suppliers";
import analyticsRoutes from "@routes/analytics";
import digitalTwinRoutes from "@routes/digitalTwin";
import { errorHandler } from "@middleware/errorHandler";
import {
  connectRedis,
  redisSubscriber,
  SHIPMENT_EVENTS_CHANNEL,
} from "@cache/client";

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ status: "ok" }));

app.use("/api/auth", authRoutes);
app.use("/api/shipments", shipmentRoutes);
app.use("/api/warehouses", warehouseRoutes);
app.use("/api/simulation", simulationRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/inventory", inventoryRoutes);
app.use("/api/suppliers", supplierRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/digital-twin", digitalTwinRoutes);

// Must be registered after all routes — Express recognizes it as error
// middleware by its 4-argument signature. Anything an asyncHandler-wrapped
// controller throws (zod validation errors, DB errors after rollback,
// etc.) lands here as clean JSON instead of an unhandled rejection.
app.use(errorHandler);

const httpServer = createServer(app);
const io = new SocketIOServer(httpServer, {
  cors: { origin: "*" },
});

io.on("connection", (socket) => {
  console.log("Client connected:", socket.id);
  socket.on("disconnect", () => console.log("Client disconnected:", socket.id));
});

async function bootstrap() {
  await connectRedis();

  // Bridge: Redis pub/sub -> Socket.IO -> frontend.
  // This is what makes a shipment status change in the DB instantly move
  // a truck in the 3D Digital Twin on every connected client's screen.
  await redisSubscriber.subscribe(SHIPMENT_EVENTS_CHANNEL, (message: string) => {
    const event = JSON.parse(message);
    io.emit("shipment:update", event);
  });

  const PORT = process.env.BACKEND_PORT || 4000;
  httpServer.listen(PORT, () => {
    console.log(`LogiSphere backend listening on port ${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error("Failed to start backend", err);
  process.exit(1);
});
