import { Router } from "express";
import { requireAuth, requireRole } from "@middleware/auth";
import { asyncHandler } from "@middleware/asyncHandler";
import { simulateDisruption } from "@controllers/simulationController";

const router = Router();

router.post(
  "/disrupt",
  requireAuth,
  requireRole("admin", "warehouse_manager"),
  asyncHandler(simulateDisruption)
);

export default router;
