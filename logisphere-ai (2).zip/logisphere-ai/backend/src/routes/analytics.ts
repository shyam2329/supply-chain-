import { Router } from "express";
import { requireAuth } from "@middleware/auth";
import { asyncHandler } from "@middleware/asyncHandler";
import { getAnalytics } from "@controllers/analyticsController";

const router = Router();

router.get("/", requireAuth, asyncHandler(getAnalytics));

export default router;
