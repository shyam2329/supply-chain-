import { Response } from "express";
import { pool } from "@config/db";
import { publishShipmentEvent } from "@cache/client";
import { AuthedRequest } from "@middleware/auth";
import { isTransitionAllowed, ShipmentStatus } from "@services/shipmentTransitions";

type SimulationType =
  | "road_blockage"
  | "bad_weather"
  | "vehicle_breakdown"
  | "warehouse_overload"
  | "supplier_delay";

const SIMULATION_CONFIG: Record<
  SimulationType,
  { label: string; delayMinutes: number; reason: string }
> = {
  road_blockage: {
    label: "Road Blockage",
    delayMinutes: 25,
    reason: "Road blockage reported on the main route",
  },
  bad_weather: {
    label: "Bad Weather",
    delayMinutes: 40,
    reason: "Heavy rain slowing traffic along the route",
  },
  vehicle_breakdown: {
    label: "Vehicle Breakdown",
    delayMinutes: 60,
    reason: "Vehicle breakdown — maintenance dispatched",
  },
  warehouse_overload: {
    label: "Warehouse Overload",
    delayMinutes: 15,
    reason: "Origin warehouse at capacity, loading delayed",
  },
  supplier_delay: {
    label: "Supplier Delay",
    delayMinutes: 90,
    reason: "Upstream supplier shipment running late",
  },
};

/**
 * generateInsight() is intentionally isolated so it can be swapped for a
 * real AI/ML service later without touching the route or DB logic below —
 * same input shape (shipment + disruption), same output shape (string).
 */
function generateInsight(
  referenceCode: string,
  disruption: SimulationType,
  delayMinutes: number
): string {
  const config = SIMULATION_CONFIG[disruption];
  const alternateRouteSaving = Math.round(delayMinutes * 0.3);
  return `Shipment ${referenceCode} has a high delay risk because of ${config.label.toLowerCase()}. Estimated delay: ${delayMinutes} minutes. An alternate route could reduce the estimated delay by ${alternateRouteSaving} minutes.`;
}

export async function simulateDisruption(req: AuthedRequest, res: Response) {
  const { shipmentId, type } = req.body as { shipmentId: string; type: SimulationType };

  if (!shipmentId || !SIMULATION_CONFIG[type]) {
    return res.status(400).json({ error: "shipmentId and a valid simulation type are required" });
  }

  const config = SIMULATION_CONFIG[type];

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const currentRes = await client.query(
      `SELECT status, reference_code FROM shipments WHERE id = $1 FOR UPDATE`,
      [shipmentId]
    );

    if (currentRes.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Shipment not found" });
    }

    const currentStatus = currentRes.rows[0].status as ShipmentStatus;

    if (!isTransitionAllowed(currentStatus, "delayed")) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: `Cannot simulate a delay on a shipment that is "${currentStatus}" — only dispatched/in_transit/delayed shipments can be disrupted.`,
      });
    }

    const updated = await client.query(
      `UPDATE shipments
       SET status = 'delayed', delay_reason = $1, updated_at = now()
       WHERE id = $2
       RETURNING *`,
      [config.reason, shipmentId]
    );

    await client.query(
      `INSERT INTO shipment_events (shipment_id, status, note)
       VALUES ($1, 'delayed', $2)`,
      [shipmentId, `Simulated: ${config.label}`]
    );

    await client.query("COMMIT");

    // --- Database write is final and successful past this point. ---
    const shipment = updated.rows[0];
    const insight = generateInsight(shipment.reference_code, type, config.delayMinutes);

    let realtimeDelivered = true;
    try {
      await publishShipmentEvent({
        shipmentId: shipment.id,
        referenceCode: shipment.reference_code,
        status: shipment.status,
        routeProgress: shipment.route_progress,
        assignedBay: shipment.assigned_bay,
        delayReason: shipment.delay_reason,
        timestamp: new Date().toISOString(),
      });
    } catch (publishErr) {
      realtimeDelivered = false;
      console.error(
        `[shipment ${shipment.reference_code}] Simulation committed but Redis publish failed:`,
        publishErr
      );
    }

    res.json({
      shipment: { ...shipment, realtimeDelivered },
      simulation: { type, label: config.label, delayMinutes: config.delayMinutes },
      insight,
    });
  } catch (err) {
    await client.query("ROLLBACK");
    throw err; // handled by the centralized error middleware
  } finally {
    client.release();
  }
}
