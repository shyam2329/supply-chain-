import { createClient } from "redis";

const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";

// Separate clients: Redis pub/sub requires the subscriber connection
// to be dedicated (it can't run normal commands while subscribed).
export const redisPublisher = createClient({ url: REDIS_URL });
export const redisSubscriber = redisPublisher.duplicate();

export const SHIPMENT_EVENTS_CHANNEL = "shipment:events";

export async function connectRedis() {
  await redisPublisher.connect();
  await redisSubscriber.connect();
  console.log("Redis publisher + subscriber connected");
}

export async function publishShipmentEvent(payload: unknown) {
  await redisPublisher.publish(SHIPMENT_EVENTS_CHANNEL, JSON.stringify(payload));
}
