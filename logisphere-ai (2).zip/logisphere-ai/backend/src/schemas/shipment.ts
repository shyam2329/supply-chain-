import { z } from "zod";
import { VALID_STATUSES } from "@services/shipmentTransitions";

export const updateShipmentStatusSchema = z.object({
  status: z.enum(VALID_STATUSES as [string, ...string[]]),
  note: z.string().max(255).optional(),
  delay_reason: z.string().max(255).optional(),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
  route_progress: z.number().min(0).max(100).optional(),
});

export type UpdateShipmentStatusBody = z.infer<typeof updateShipmentStatusSchema>;
