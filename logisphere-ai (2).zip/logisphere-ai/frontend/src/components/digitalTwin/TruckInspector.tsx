import { useEffect, useState } from "react";
import { Shipment } from "@apptypes/index";
import { fetchShipmentTimeline } from "@services/shipmentService";
import { getFleetHealth, FLEET_HEALTH_ICON } from "@three/fleetHealth";

const TIMELINE_STEPS: Shipment["status"][] = [
  "pending",
  "dispatched",
  "in_transit",
  "delivered",
];

interface TimelineEvent {
  id: string;
  status: string;
  note: string | null;
  created_at: string;
}

interface TruckInspectorProps {
  shipment: Shipment | null;
  onClose: () => void;
}

export default function TruckInspector({ shipment, onClose }: TruckInspectorProps) {
  const [events, setEvents] = useState<TimelineEvent[]>([]);

  useEffect(() => {
    if (!shipment) return;
    fetchShipmentTimeline(shipment.id)
      .then(setEvents)
      .catch(() => setEvents([]));
  }, [shipment?.id]);

  if (!shipment) {
    return (
      <div className="text-sm text-gray-500 p-4">
        Click a truck in the scene to inspect its shipment.
      </div>
    );
  }

  const health = getFleetHealth(shipment.id);
  const activeStepIndex =
    shipment.status === "delayed"
      ? TIMELINE_STEPS.indexOf("in_transit")
      : TIMELINE_STEPS.indexOf(shipment.status as any);

  return (
    <div className="p-4 space-y-4 text-sm">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs text-gray-500 uppercase tracking-wide">Truck Details</div>
          <div className="text-lg font-bold text-logisphere-accent">{shipment.reference_code}</div>
        </div>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-300 text-xs">
          ✕
        </button>
      </div>

      <div className="grid grid-cols-2 gap-y-2 gap-x-3 text-gray-300">
        <span className="text-gray-500">Status</span>
        <span className="capitalize">{shipment.status.replace("_", " ")}</span>

        <span className="text-gray-500">Cargo qty</span>
        <span>{shipment.quantity}</span>

        <span className="text-gray-500">Destination</span>
        <span>{shipment.destination_label ?? "—"}</span>

        <span className="text-gray-500">Route progress</span>
        <span>{Math.round(shipment.route_progress)}%</span>

        <span className="text-gray-500">Fleet health</span>
        <span>
          {FLEET_HEALTH_ICON[health]} {health}
        </span>

        {shipment.delay_reason && (
          <>
            <span className="text-gray-500">Delay reason</span>
            <span className="text-logisphere-danger">{shipment.delay_reason}</span>
          </>
        )}
      </div>

      {/* Status timeline */}
      <div>
        <div className="text-xs text-gray-500 uppercase tracking-wide mb-2">Timeline</div>
        <div className="space-y-1">
          {TIMELINE_STEPS.map((step, i) => {
            const isActive = i === activeStepIndex;
            const isPast = i < activeStepIndex;
            return (
              <div key={step} className="flex items-center gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                    isActive
                      ? "bg-logisphere-accent"
                      : isPast
                      ? "bg-logisphere-accent/40"
                      : "bg-white/15"
                  }`}
                />
                <span
                  className={`capitalize ${
                    isActive ? "text-logisphere-accent font-semibold" : "text-gray-400"
                  }`}
                >
                  {step.replace("_", " ")}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {events.length > 0 && (
        <div>
          <div className="text-xs text-gray-500 uppercase tracking-wide mb-2">Event log</div>
          <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
            {events.map((e) => (
              <div key={e.id} className="text-xs text-gray-400 border-l border-white/10 pl-2">
                <span className="text-gray-300 capitalize">{e.status.replace("_", " ")}</span>
                {e.note ? ` — ${e.note}` : ""}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
