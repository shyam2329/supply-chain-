import { Text } from "@react-three/drei";
import { getBaySlotPosition } from "@three/layout";

interface GarageBayProps {
  bayIndex: number;
  totalBays: number;
  occupied: boolean;
}

export default function GarageBay({ bayIndex, totalBays, occupied }: GarageBayProps) {
  const [x, , z] = getBaySlotPosition(bayIndex, totalBays);

  return (
    <group position={[x, 0, z]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <planeGeometry args={[1.6, 1.8]} />
        <meshStandardMaterial
          color={occupied ? "#1E2A22" : "#161B26"}
          emissive={occupied ? "#3DDC97" : "#000000"}
          emissiveIntensity={occupied ? 0.12 : 0}
        />
      </mesh>
      <Text
        position={[0, 0.02, 0.75]}
        rotation={[-Math.PI / 2, 0, 0]}
        fontSize={0.28}
        color="#5B6472"
        anchorX="center"
        anchorY="middle"
      >
        {`BAY ${bayIndex}`}
      </Text>
    </group>
  );
}
