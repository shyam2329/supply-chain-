import { Response } from "express";
import { pool } from "@config/db";
import { AuthedRequest } from "@middleware/auth";

export async function getDashboardSummary(_req: AuthedRequest, res: Response) {
  const [shipmentCounts, warehouseCapacity, supplierPerf, delayedShipments] =
    await Promise.all([
      pool.query(`
        SELECT
          COUNT(*)::int AS total,
          COUNT(*) FILTER (WHERE status IN ('dispatched', 'in_transit'))::int AS active,
          COUNT(*) FILTER (WHERE status = 'delayed')::int AS delayed,
          COUNT(*) FILTER (WHERE status = 'pending')::int AS pending
        FROM shipments
      `),
      pool.query(`
        SELECT
          COALESCE(SUM(w.capacity_units), 0) AS total_capacity,
          COALESCE(SUM(inv.used), 0) AS total_used
        FROM warehouses w
        LEFT JOIN (
          SELECT warehouse_id, SUM(quantity) AS used
          FROM inventory
          GROUP BY warehouse_id
        ) inv ON inv.warehouse_id = w.id
      `),
      pool.query(`SELECT COALESCE(AVG(on_time_rate), 0) AS avg_on_time FROM suppliers`),
      pool.query(`
        SELECT id, reference_code, delay_reason
        FROM shipments
        WHERE status = 'delayed'
        ORDER BY updated_at DESC
        LIMIT 5
      `),
    ]);

  const counts = shipmentCounts.rows[0];
  const capRow = warehouseCapacity.rows[0];
  const totalCapacity = Number(capRow.total_capacity);
  const totalUsed = Number(capRow.total_used);
  const warehouseCapacityPct = totalCapacity > 0 ? Math.round((totalUsed / totalCapacity) * 100) : 0;

  const aiInsights = delayedShipments.rows.map(
    (s) =>
      `Shipment ${s.reference_code} is delayed${s.delay_reason ? `: ${s.delay_reason}` : ""}.`
  );

  res.json({
    totalShipments: counts.total,
    activeShipments: counts.active,
    delayedShipments: counts.delayed,
    warehouseCapacity: warehouseCapacityPct,
    fleetAvailability: counts.pending,
    supplierPerformance: Math.round(Number(supplierPerf.rows[0].avg_on_time)),
    deliveryPerformance: counts.delayed === 0 ? "On track" : "At risk",
    aiInsights,
  });
}
