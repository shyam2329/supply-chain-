import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "@pages/Landing";
import Login from "@pages/Login";
import Dashboard from "@pages/Dashboard";
import Inventory from "@pages/Inventory";
import Shipments from "@pages/Shipments";
import Warehouses from "@pages/Warehouses";
import Suppliers from "@pages/Suppliers";
import Analytics from "@pages/Analytics";
import DigitalTwin from "@pages/DigitalTwin";
import DashboardLayout from "@components/DashboardLayout";
import ProtectedRoute from "@components/ProtectedRoute";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />

        <Route element={<ProtectedRoute />}>
          <Route element={<DashboardLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/shipments" element={<Shipments />} />
            <Route path="/warehouses" element={<Warehouses />} />
            <Route path="/suppliers" element={<Suppliers />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/digital-twin" element={<DigitalTwin />} />
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
