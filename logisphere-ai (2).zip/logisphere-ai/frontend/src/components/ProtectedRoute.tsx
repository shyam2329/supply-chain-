import { Navigate, Outlet } from "react-router-dom";

/**
 * Guards the authenticated section of the app. This is a presence check
 * (token exists in localStorage) rather than a validity check — an
 * expired/invalid token still lets the route render, but the first API
 * call will 401 and the client.ts response interceptor bounces to
 * /login at that point. That keeps this component simple and avoids a
 * network round-trip before every route render.
 */
export default function ProtectedRoute() {
  const token = localStorage.getItem("logisphere_token");

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
}
