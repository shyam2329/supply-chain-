import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { login } from "@api/auth";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@logisphere.ai");
  const [password, setPassword] = useState("password123");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
      navigate("/dashboard");
    } catch (err: any) {
      setError(err?.response?.data?.error || "Login failed. Check your credentials.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-logisphere-bg text-gray-100">
      <form
        onSubmit={handleSubmit}
        className="w-80 bg-logisphere-panel p-8 rounded-xl border border-white/10 space-y-4"
      >
        <h1 className="text-xl font-bold mb-2">Sign in to LogiSphere</h1>

        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          className="w-full px-3 py-2 rounded-md bg-black/30 border border-white/10 text-sm"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className="w-full px-3 py-2 rounded-md bg-black/30 border border-white/10 text-sm"
        />

        {error && <p className="text-logisphere-danger text-xs">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 rounded-md bg-logisphere-accent text-black font-semibold text-sm disabled:opacity-60"
        >
          {loading ? "Signing in..." : "Sign in"}
        </button>

        <p className="text-xs text-gray-500 text-center pt-2">
          Demo: admin@logisphere.ai / password123
        </p>
      </form>
    </div>
  );
}
