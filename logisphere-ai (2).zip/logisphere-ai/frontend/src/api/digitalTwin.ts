import { apiClient } from "./client";
import { Shipment } from "@apptypes/index";
import { WarehouseWithStats } from "./warehouses";

export interface DigitalTwinInitialState {
  warehouses: WarehouseWithStats[];
  shipments: Shipment[];
}

/** Single round trip for the Digital Twin's initial state (warehouses +
 * shipments together). Subsequent updates arrive over Socket.IO — this
 * endpoint is only for the first load / manual refresh. */
export async function fetchDigitalTwinState(): Promise<DigitalTwinInitialState> {
  const { data } = await apiClient.get<DigitalTwinInitialState>("/digital-twin");
  return data;
}
