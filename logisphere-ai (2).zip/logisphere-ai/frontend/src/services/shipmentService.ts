import { fetchShipments, fetchShipmentTimeline, updateShipmentStatus } from "@api/shipments";
import { simulateDisruption, SimulationType } from "@api/simulation";
import { Shipment } from "@apptypes/index";

export { fetchShipments, fetchShipmentTimeline };

/** PENDING -> DISPATCHED. Truck leaves its garage bay onto the road. */
export function dispatchTruck(shipment: Shipment) {
  return updateShipmentStatus(shipment.id, "dispatched", { route_progress: 5 });
}

/** DISPATCHED/IN_TRANSIT -> IN_TRANSIT, nudging progress forward. */
export function continueJourney(shipment: Shipment) {
  const next = Math.min(95, (shipment.route_progress ?? 0) + 25);
  return updateShipmentStatus(shipment.id, "in_transit", { route_progress: next });
}

/** Any active status -> DELAYED, with a manual reason (vs. simulateDisruption's rule-based ones). */
export function markDelayed(shipment: Shipment, reason = "Manually flagged delay") {
  return updateShipmentStatus(shipment.id, "delayed", { delay_reason: reason });
}

/** IN_TRANSIT/DELAYED -> DELIVERED. Truck reaches destination marker. */
export function markDelivered(shipment: Shipment) {
  return updateShipmentStatus(shipment.id, "delivered", { route_progress: 100 });
}

/** DELIVERED -> RETURNED. Truck drives back toward the warehouse and parks. */
export function returnToGarage(shipment: Shipment) {
  return updateShipmentStatus(shipment.id, "returned", { route_progress: 0 });
}

export function runSimulation(shipment: Shipment, type: SimulationType) {
  return simulateDisruption(shipment.id, type);
}
