import { Response } from "express";
import { pool } from "@config/db";
import { AuthedRequest } from "@middleware/auth";

export async function listSuppliers(_req: AuthedRequest, res: Response) {
  const result = await pool.query(`
    SELECT
      s.id,
      s.name,
      s.contact_email,
      s.contact_phone,
      s.on_time_rate,
      s.performance_score,
      COALESCE(p.product_count, 0)::int AS product_count
    FROM suppliers s
    LEFT JOIN (
      SELECT supplier_id, COUNT(*) AS product_count
      FROM products
      GROUP BY supplier_id
    ) p ON p.supplier_id = s.id
    ORDER BY s.performance_score DESC
  `);
  res.json(result.rows);
}
