export type FleetHealth = "Healthy" | "Needs Inspection" | "Maintenance Required";

/**
 * Deterministic pseudo-health so the same shipment always shows the same
 * health state across reloads (no real telematics feed yet). Swap this
 * for a real fleet-maintenance API later — callers only depend on the
 * FleetHealth return type.
 */
export function getFleetHealth(shipmentId: string): FleetHealth {
  let hash = 0;
  for (let i = 0; i < shipmentId.length; i++) {
    hash = (hash * 31 + shipmentId.charCodeAt(i)) % 997;
  }
  const bucket = hash % 10;
  if (bucket < 7) return "Healthy";
  if (bucket < 9) return "Needs Inspection";
  return "Maintenance Required";
}

export const FLEET_HEALTH_ICON: Record<FleetHealth, string> = {
  Healthy: "✅",
  "Needs Inspection": "🔧",
  "Maintenance Required": "⚠️",
};
