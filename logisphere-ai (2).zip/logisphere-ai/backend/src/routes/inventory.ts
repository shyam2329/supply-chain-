import { Router } from "express";
import { requireAuth, requireRole } from "@middleware/auth";
import { asyncHandler } from "@middleware/asyncHandler";
import { listInventory, adjustStock } from "@controllers/inventoryController";

const router = Router();

router.get("/", requireAuth, asyncHandler(listInventory));
router.patch(
  "/:id/adjust",
  requireAuth,
  requireRole("admin", "warehouse_manager"),
  asyncHandler(adjustStock)
);

export default router;
