import { Link } from "react-router-dom";

export default function Landing() {
  return (
    <div className="min-h-screen bg-logisphere-bg text-gray-100 flex flex-col">
      <header className="flex items-center justify-between px-8 py-5">
        <div className="text-lg font-bold tracking-tight">LogiSphere AI</div>
        <Link
          to="/login"
          className="px-4 py-2 rounded-md text-sm font-semibold bg-logisphere-accent text-black hover:opacity-90 transition-opacity"
        >
          Get Started →
        </Link>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center text-center px-6">
        <p className="text-logisphere-accent text-sm font-semibold tracking-widest uppercase mb-4">
          Smart Supply Chain Visibility
        </p>
        <h1 className="text-4xl md:text-6xl font-bold max-w-3xl leading-tight">
          See Every Movement.
          <br />
          Control Every Journey.
        </h1>
        <p className="text-gray-400 max-w-xl mt-6">
          LogiSphere AI turns your shipment data into a living 3D Digital Twin —
          real status changes move real trucks, in real time.
        </p>
        <div className="flex gap-3 mt-8">
          <Link
            to="/login"
            className="px-6 py-3 rounded-md text-sm font-semibold bg-logisphere-accent text-black hover:opacity-90 transition-opacity"
          >
            Sign In
          </Link>
        </div>
        {/* TODO: replace with the full cursor-reactive 3D hero scene
            (warehouse, trucks, animated routes) once the marketing site
            gets its own pass — the Digital Twin page already has the
            real, data-driven version of this 3D world at /digital-twin. */}
      </main>

      <footer className="text-center text-xs text-gray-600 py-6">
        LogiSphere AI — built with React Three Fiber, Node.js, PostgreSQL & Redis
      </footer>
    </div>
  );
}
