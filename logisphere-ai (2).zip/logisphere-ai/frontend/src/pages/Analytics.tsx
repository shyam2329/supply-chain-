import { useEffect, useState, ReactNode } from "react";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { fetchAnalytics, AnalyticsData } from "@api/analytics";

const STATUS_COLORS: Record<string, string> = {
  pending: "#5B6472",
  dispatched: "#4C8DFF",
  in_transit: "#3DDC97",
  delayed: "#FF4D4F",
  delivered: "#4C8DFF",
  returned: "#8A8F98",
  cancelled: "#3A3F47",
};

const HEALTH_COLORS: Record<string, string> = {
  good: "#3DDC97",
  low_stock: "#FFB020",
  out_of_stock: "#FF4D4F",
};

function ChartCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="bg-logisphere-panel border border-white/10 rounded-xl p-4">
      <div className="text-sm font-semibold mb-4">{title}</div>
      <div className="h-64">{children}</div>
    </div>
  );
}

export default function Analytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAnalytics()
      .then(setData)
      .catch(() => setError("Failed to load analytics."))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-sm text-gray-500">Loading analytics...</p>;
  if (error) return <p className="text-sm text-logisphere-danger">{error}</p>;
  if (!data) return null;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Analytics</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ChartCard title="Shipment Status Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data.shipmentStatusDistribution}
                dataKey="count"
                nameKey="status"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label={(entry) => `${entry.status}: ${entry.count}`}
              >
                {data.shipmentStatusDistribution.map((d) => (
                  <Cell key={d.status} fill={STATUS_COLORS[d.status] ?? "#5B6472"} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "#121826", border: "1px solid #2A3240" }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Warehouse Utilization">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.warehouseUtilization}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E2530" />
              <XAxis dataKey="name" stroke="#5B6472" fontSize={12} />
              <YAxis stroke="#5B6472" fontSize={12} unit="%" />
              <Tooltip contentStyle={{ background: "#121826", border: "1px solid #2A3240" }} />
              <Bar dataKey="utilization_pct" name="Utilization %" fill="#3DDC97" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Inventory Health">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data.inventoryHealth}
                dataKey="count"
                nameKey="status"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label={(entry) => `${entry.status}: ${entry.count}`}
              >
                {data.inventoryHealth.map((d) => (
                  <Cell key={d.status} fill={HEALTH_COLORS[d.status] ?? "#5B6472"} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "#121826", border: "1px solid #2A3240" }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Supplier Performance">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.supplierPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E2530" />
              <XAxis dataKey="name" stroke="#5B6472" fontSize={12} />
              <YAxis stroke="#5B6472" fontSize={12} />
              <Tooltip contentStyle={{ background: "#121826", border: "1px solid #2A3240" }} />
              <Legend />
              <Bar dataKey="on_time_rate" name="On-time %" fill="#4C8DFF" radius={[4, 4, 0, 0]} />
              <Bar dataKey="performance_score" name="Score /10" fill="#3DDC97" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Shipment Events Over Time">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.shipmentEventsOverTime}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E2530" />
              <XAxis dataKey="day" stroke="#5B6472" fontSize={11} />
              <YAxis stroke="#5B6472" fontSize={12} allowDecimals={false} />
              <Tooltip contentStyle={{ background: "#121826", border: "1px solid #2A3240" }} />
              <Bar dataKey="count" name="Events" fill="#4C8DFF" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}
