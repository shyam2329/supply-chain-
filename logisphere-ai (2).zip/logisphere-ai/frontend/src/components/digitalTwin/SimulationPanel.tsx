import { useState } from "react";
import { Shipment } from "@apptypes/index";
import { runSimulation } from "@services/shipmentService";
import { SimulationType } from "@api/simulation";

interface SimulationPanelProps {
  shipment: Shipment | null;
  /** Called with the updated shipment from the simulation response — see
   * TwinControls for why this merges directly instead of refetching. */
  onUpdated: (updated: Shipment) => void;
}

const DISRUPTIONS: Array<{ type: SimulationType; label: string; icon: string }> = [
  { type: "road_blockage", label: "Road Blockage", icon: "🚧" },
  { type: "bad_weather", label: "Bad Weather", icon: "🌧" },
  { type: "vehicle_breakdown", label: "Vehicle Breakdown", icon: "🚚" },
  { type: "warehouse_overload", label: "Warehouse Overload", icon: "📦" },
  { type: "supplier_delay", label: "Supplier Delay", icon: "🚢" },
];

export default function SimulationPanel({ shipment, onUpdated }: SimulationPanelProps) {
  const [pendingType, setPendingType] = useState<SimulationType | null>(null);
  const [insight, setInsight] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);

  async function handleClick(type: SimulationType) {
    if (!shipment) return;
    setPendingType(type);
    setInsight(null);
    setWarning(null);
    try {
      const result = await runSimulation(shipment, type);
      setInsight(result.insight);
      onUpdated(result.shipment);
      if (result.shipment.realtimeDelivered === false) {
        setWarning("Saved to the database, but the live update (Redis/Socket.IO) may not have reached other viewers.");
      }
    } catch (err: any) {
      setWarning(err?.response?.data?.error ?? "Simulation failed.");
    } finally {
      setPendingType(null);
    }
  }

  return (
    <div className="p-4 border-t border-white/10">
      <div className="text-xs text-gray-500 uppercase tracking-wide mb-2">
        Simulation Mode — AI Logistics
      </div>
      {!shipment && (
        <p className="text-xs text-gray-500 mb-2">Select a truck to simulate a disruption.</p>
      )}
      <div className="grid grid-cols-2 gap-2">
        {DISRUPTIONS.map((d) => (
          <button
            key={d.type}
            disabled={!shipment || pendingType === d.type}
            onClick={() => handleClick(d.type)}
            className="flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs border border-white/10 bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <span>{d.icon}</span>
            {pendingType === d.type ? "..." : d.label}
          </button>
        ))}
      </div>

      {insight && (
        <div className="mt-3 text-xs bg-logisphere-accent/10 border border-logisphere-accent/30 rounded-md p-3 text-logisphere-accent leading-relaxed">
          🤖 {insight}
        </div>
      )}
      {warning && <p className="text-xs text-logisphere-warn mt-2">{warning}</p>}
    </div>
  );
}
