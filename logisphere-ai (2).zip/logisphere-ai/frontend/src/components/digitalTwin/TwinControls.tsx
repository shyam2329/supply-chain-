import { useState } from "react";
import { Shipment } from "@apptypes/index";
import {
  dispatchTruck,
  continueJourney,
  markDelayed,
  markDelivered,
  returnToGarage,
} from "@services/shipmentService";

interface TwinControlsProps {
  shipment: Shipment | null;
  /** Called with the updated shipment straight from the PATCH response —
   * NOT a signal to refetch everything. See useDigitalTwinState's
   * applyShipmentUpdate() for why: refetching here would race the
   * Socket.IO event for this same change. */
  onUpdated: (updated: Shipment) => void;
}

const BUTTONS: Array<{
  key: string;
  label: string;
  icon: string;
  run: (s: Shipment) => Promise<Shipment>;
  enabled: (s: Shipment) => boolean;
}> = [
  {
    key: "dispatch",
    label: "Dispatch Truck",
    icon: "▶",
    run: dispatchTruck,
    enabled: (s) => s.status === "pending",
  },
  {
    key: "delay",
    label: "Simulate Delay",
    icon: "⚠",
    run: (s) => markDelayed(s, "Manually flagged from Digital Twin controls"),
    enabled: (s) => ["dispatched", "in_transit"].includes(s.status),
  },
  {
    key: "continue",
    label: "Continue Journey",
    icon: "🚚",
    run: continueJourney,
    enabled: (s) => ["dispatched", "in_transit", "delayed"].includes(s.status),
  },
  {
    key: "deliver",
    label: "Mark Delivered",
    icon: "📦",
    run: markDelivered,
    enabled: (s) => ["in_transit", "delayed"].includes(s.status),
  },
  {
    key: "return",
    label: "Return to Garage",
    icon: "↩",
    run: returnToGarage,
    enabled: (s) => s.status === "delivered",
  },
];

export default function TwinControls({ shipment, onUpdated }: TwinControlsProps) {
  const [pendingKey, setPendingKey] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);

  async function handleClick(btn: (typeof BUTTONS)[number]) {
    if (!shipment) return;
    setPendingKey(btn.key);
    setWarning(null);
    try {
      const updated = await btn.run(shipment);
      onUpdated(updated);
      if (updated.realtimeDelivered === false) {
        setWarning("Saved to the database, but the live update (Redis/Socket.IO) may not have reached other viewers.");
      }
    } catch (err: any) {
      setWarning(err?.response?.data?.error ?? "Action failed.");
    } finally {
      setPendingKey(null);
    }
  }

  return (
    <div className="p-4 border-t border-white/10">
      <div className="text-xs text-gray-500 uppercase tracking-wide mb-2">Live Demo Controls</div>
      {!shipment && (
        <p className="text-xs text-gray-500 mb-2">Select a truck to control its shipment.</p>
      )}
      <div className="grid grid-cols-1 gap-2">
        {BUTTONS.map((btn) => {
          const disabled = !shipment || !btn.enabled(shipment) || pendingKey === btn.key;
          return (
            <button
              key={btn.key}
              disabled={disabled}
              onClick={() => handleClick(btn)}
              className="flex items-center gap-2 px-3 py-2 rounded-md text-sm border border-white/10 bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <span>{btn.icon}</span>
              {pendingKey === btn.key ? "Working..." : btn.label}
            </button>
          );
        })}
      </div>
      {warning && <p className="text-xs text-logisphere-warn mt-2">{warning}</p>}
    </div>
  );
}
