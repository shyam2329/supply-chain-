import { apiClient } from "./client";
import { Shipment, ShipmentStatus } from "@apptypes/index";

export async function fetchShipments(): Promise<Shipment[]> {
  const { data } = await apiClient.get<Shipment[]>("/shipments");
  return data;
}

export async function fetchShipmentTimeline(shipmentId: string) {
  const { data } = await apiClient.get(`/shipments/${shipmentId}/timeline`);
  return data;
}

export async function updateShipmentStatus(
  shipmentId: string,
  status: ShipmentStatus,
  extra?: { delay_reason?: string; route_progress?: number; note?: string }
) {
  const { data } = await apiClient.patch<Shipment>(
    `/shipments/${shipmentId}/status`,
    { status, ...extra }
  );
  return data;
}
