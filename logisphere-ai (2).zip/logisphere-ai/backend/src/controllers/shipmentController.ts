import { Response } from "express";
import { pool } from "@config/db";
import { publishShipmentEvent } from "@cache/client";
import { AuthedRequest } from "@middleware/auth";
import { updateShipmentStatusSchema } from "@schemas/shipment";
import {
  isTransitionAllowed,
  resolveBayForTransition,
  ShipmentStatus,
} from "@services/shipmentTransitions";

export async function listShipments(_req: AuthedRequest, res: Response) {
  const result = await pool.query(
    `SELECT s.*, ow.name AS origin_name, dw.name AS destination_name
     FROM shipments s
     LEFT JOIN warehouses ow ON ow.id = s.origin_warehouse_id
     LEFT JOIN warehouses dw ON dw.id = s.destination_warehouse_id
     ORDER BY s.updated_at DESC`
  );
  res.json(result.rows);
}

export async function getShipmentTimeline(req: AuthedRequest, res: Response) {
  const { id } = req.params;
  const events = await pool.query(
    `SELECT * FROM shipment_events WHERE shipment_id = $1 ORDER BY created_at ASC`,
    [id]
  );
  res.json(events.rows);
}

/**
 * The core Digital Twin write path:
 * 1. Validate the request body (zod) and the requested status transition.
 * 2. Persist the new status + resolve garage bay lifecycle to `shipments`.
 * 3. Log it in `shipment_events` (append-only history).
 * 4. COMMIT — at this point the write has genuinely succeeded.
 * 5. Publish to Redis so Socket.IO can push the update to the frontend.
 *    A failure here does NOT mean the database change failed, so it must
 *    never trigger a rollback or a 500 that implies the update didn't
 *    happen — the shipment really did change. We log it and tell the
 *    caller about it via a `realtimeDelivered: false` flag instead.
 */
export async function updateShipmentStatus(req: AuthedRequest, res: Response) {
  const { id } = req.params;
  const parsed = updateShipmentStatusSchema.parse(req.body);
  const { status, note, delay_reason, latitude, longitude, route_progress } = parsed;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const currentRes = await client.query(
      `SELECT status, origin_warehouse_id FROM shipments WHERE id = $1 FOR UPDATE`,
      [id]
    );

    if (currentRes.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Shipment not found" });
    }

    const currentStatus = currentRes.rows[0].status as ShipmentStatus;
    const originWarehouseId: string | null = currentRes.rows[0].origin_warehouse_id;

    if (!isTransitionAllowed(currentStatus, status as ShipmentStatus)) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: `Invalid status transition: ${currentStatus} -> ${status}`,
      });
    }

    const bayResolution = await resolveBayForTransition(
      client,
      status as ShipmentStatus,
      originWarehouseId
    );

    const updated = await client.query(
      `UPDATE shipments
       SET status = $1,
           delay_reason = COALESCE($2, delay_reason),
           route_progress = COALESCE($3, route_progress),
           assigned_bay = CASE WHEN $4::boolean THEN $5::int ELSE assigned_bay END,
           updated_at = now()
       WHERE id = $6
       RETURNING *`,
      [
        status,
        delay_reason ?? null,
        route_progress ?? null,
        bayResolution !== undefined, // whether to touch assigned_bay at all
        bayResolution ?? null,
        id,
      ]
    );

    await client.query(
      `INSERT INTO shipment_events (shipment_id, status, latitude, longitude, note)
       VALUES ($1, $2, $3, $4, $5)`,
      [id, status, latitude ?? null, longitude ?? null, note ?? null]
    );

    await client.query("COMMIT");

    // --- Past this point the database write is final and successful. ---
    const shipment = updated.rows[0];

    let realtimeDelivered = true;
    try {
      await publishShipmentEvent({
        shipmentId: shipment.id,
        referenceCode: shipment.reference_code,
        status: shipment.status,
        routeProgress: shipment.route_progress,
        assignedBay: shipment.assigned_bay,
        delayReason: shipment.delay_reason,
        timestamp: new Date().toISOString(),
      });
    } catch (publishErr) {
      // Redis being down does not mean the update failed — it already
      // committed. Log it distinctly and tell the caller the live/Socket.IO
      // push may not have gone out, but the write itself succeeded.
      realtimeDelivered = false;
      console.error(
        `[shipment ${shipment.reference_code}] DB update committed but Redis publish failed:`,
        publishErr
      );
    }

    res.json({ ...shipment, realtimeDelivered });
  } catch (err) {
    // Only reachable for failures BEFORE commit (transition check or a
    // query error) — safe to roll back. A zod validation error is thrown
    // before this try block even starts, so it never reaches here.
    await client.query("ROLLBACK");
    throw err; // handled by the centralized error middleware
  } finally {
    client.release();
  }
}
