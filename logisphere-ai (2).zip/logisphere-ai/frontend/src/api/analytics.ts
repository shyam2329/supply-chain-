import { apiClient } from "./client";

export interface AnalyticsData {
  shipmentStatusDistribution: { status: string; count: number }[];
  warehouseUtilization: {
    name: string;
    capacity_units: number;
    used_units: number;
    utilization_pct: number;
  }[];
  inventoryHealth: { status: string; count: number }[];
  supplierPerformance: { name: string; on_time_rate: number; performance_score: number }[];
  shipmentEventsOverTime: { day: string; status: string; count: number }[];
}

export async function fetchAnalytics(): Promise<AnalyticsData> {
  const { data } = await apiClient.get<AnalyticsData>("/analytics");
  return data;
}
