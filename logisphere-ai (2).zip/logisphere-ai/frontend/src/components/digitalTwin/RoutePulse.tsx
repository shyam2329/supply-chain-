import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Shipment } from "@apptypes/index";
import { MERGE_POINT, DESTINATION_POINT, roadProgress } from "@three/layout";

interface RoutePulseProps {
  shipment: Shipment;
}

export default function RoutePulse({ shipment }: RoutePulseProps) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (!meshRef.current) return;
    const t = roadProgress(shipment);
    meshRef.current.position.set(
      MERGE_POINT[0] + (DESTINATION_POINT[0] - MERGE_POINT[0]) * t,
      0.15,
      MERGE_POINT[2] + (DESTINATION_POINT[2] - MERGE_POINT[2]) * t
    );
    meshRef.current.visible = t > 0 && t < 1 && shipment.status !== "pending";
  });

  const color = shipment.status === "delayed" ? "#FF4D4F" : "#3DDC97";

  return (
    <mesh ref={meshRef}>
      <sphereGeometry args={[0.09, 12, 12]} />
      <meshBasicMaterial color={color} />
    </mesh>
  );
}
