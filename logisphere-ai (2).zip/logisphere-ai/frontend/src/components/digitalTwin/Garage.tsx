import GarageBay from "./GarageBay";
import { Shipment } from "@apptypes/index";

interface GarageProps {
  totalBays: number;
  shipments: Shipment[];
}

export default function Garage({ totalBays, shipments }: GarageProps) {
  const occupiedBays = new Set(
    shipments.filter((s) => s.status === "pending").map((s) => s.assigned_bay)
  );

  return (
    <group>
      {Array.from({ length: totalBays }, (_, i) => i + 1).map((bayIndex) => (
        <GarageBay
          key={bayIndex}
          bayIndex={bayIndex}
          totalBays={totalBays}
          occupied={occupiedBays.has(bayIndex)}
        />
      ))}
    </group>
  );
}
