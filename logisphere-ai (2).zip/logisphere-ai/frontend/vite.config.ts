import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@components": path.resolve(__dirname, "src/components"),
      "@pages": path.resolve(__dirname, "src/pages"),
      "@three": path.resolve(__dirname, "src/three"),
      "@api": path.resolve(__dirname, "src/api"),
      "@hooks": path.resolve(__dirname, "src/hooks"),
      "@apptypes": path.resolve(__dirname, "src/types"),
      "@services": path.resolve(__dirname, "src/services"),
    },
  },
  server: {
    host: true,
    port: 5173,
  },
});
