import { useEffect, useState } from "react";
import { Shipment } from "@apptypes/index";
import { fetchShipments } from "@api/shipments";
import {
  dispatchTruck,
  continueJourney,
  markDelayed,
  markDelivered,
  returnToGarage,
} from "@services/shipmentService";
import StatusBadge from "@components/StatusBadge";

const ACTIONS: Array<{
  key: string;
  label: string;
  run: (s: Shipment) => Promise<Shipment>;
  enabled: (s: Shipment) => boolean;
}> = [
  { key: "dispatch", label: "Dispatch", run: dispatchTruck, enabled: (s) => s.status === "pending" },
  {
    key: "continue",
    label: "Continue",
    run: continueJourney,
    enabled: (s) => ["dispatched", "in_transit", "delayed"].includes(s.status),
  },
  {
    key: "delay",
    label: "Delay",
    run: (s) => markDelayed(s),
    enabled: (s) => ["dispatched", "in_transit"].includes(s.status),
  },
  {
    key: "deliver",
    label: "Deliver",
    run: markDelivered,
    enabled: (s) => ["in_transit", "delayed"].includes(s.status),
  },
  {
    key: "return",
    label: "Return",
    run: returnToGarage,
    enabled: (s) => s.status === "delivered",
  },
];

export default function Shipments() {
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busyKey, setBusyKey] = useState<string | null>(null);

  function load() {
    setLoading(true);
    setError(null);
    fetchShipments()
      .then(setShipments)
      .catch(() => setError("Failed to load shipments."))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  // Merges the action's own response into local state instead of
  // refetching the whole list. Refetching immediately after a PATCH can
  // race a concurrent Socket.IO event for the same change (whichever
  // resolves last wins) — merging the PATCH's own response sidesteps
  // that since it's guaranteed to reflect the write that just happened.
  function applyUpdate(updated: Shipment) {
    setShipments((prev) => prev.map((s) => (s.id === updated.id ? { ...s, ...updated } : s)));
  }

  async function handleAction(shipment: Shipment, action: (typeof ACTIONS)[number]) {
    const key = `${shipment.id}:${action.key}`;
    setBusyKey(key);
    try {
      const updated = await action.run(shipment);
      applyUpdate(updated);
      if (updated.realtimeDelivered === false) {
        setError(
          `${shipment.reference_code} updated, but the live broadcast (Redis/Socket.IO) may not have reached other viewers.`
        );
      } else {
        setError(null);
      }
    } catch (err: any) {
      setError(err?.response?.data?.error ?? `Action "${action.label}" failed for ${shipment.reference_code}.`);
    } finally {
      setBusyKey(null);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Shipments</h1>
        <span className="text-xs text-gray-500">
          {shipments.length} shipment{shipments.length === 1 ? "" : "s"} — actions here update the
          same PostgreSQL → Redis → Socket.IO pipeline the Digital Twin uses
        </span>
      </div>

      {loading && <p className="text-sm text-gray-500">Loading shipments...</p>}
      {error && <p className="text-sm text-logisphere-warn mb-3">{error}</p>}
      {!loading && shipments.length === 0 && (
        <p className="text-sm text-gray-500">No shipments yet.</p>
      )}

      {!loading && shipments.length > 0 && (
        <div className="bg-logisphere-panel border border-white/10 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b border-white/10">
                <th className="px-4 py-3 font-medium">Reference</th>
                <th className="px-4 py-3 font-medium">Destination</th>
                <th className="px-4 py-3 font-medium">Qty</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Progress</th>
                <th className="px-4 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {shipments.map((s) => (
                <tr key={s.id} className="border-b border-white/5 last:border-0 align-top">
                  <td className="px-4 py-3 font-medium">{s.reference_code}</td>
                  <td className="px-4 py-3 text-gray-400">
                    {s.destination_label ?? "—"}
                    {s.delay_reason && (
                      <div className="text-logisphere-danger text-xs mt-0.5">⚠ {s.delay_reason}</div>
                    )}
                  </td>
                  <td className="px-4 py-3">{s.quantity}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={s.status} />
                  </td>
                  <td className="px-4 py-3 w-32">
                    <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-logisphere-accent"
                        style={{ width: `${s.route_progress}%` }}
                      />
                    </div>
                    <div className="text-xs text-gray-600 mt-1">{Math.round(s.route_progress)}%</div>
                  </td>
                  <td className="px-4 py-3 text-right space-x-1.5">
                    {ACTIONS.filter((a) => a.enabled(s)).map((a) => (
                      <button
                        key={a.key}
                        disabled={busyKey === `${s.id}:${a.key}`}
                        onClick={() => handleAction(s, a)}
                        className="px-2 py-1 rounded-md text-xs border border-white/10 bg-white/5 hover:bg-white/10 disabled:opacity-40"
                      >
                        {busyKey === `${s.id}:${a.key}` ? "..." : a.label}
                      </button>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
