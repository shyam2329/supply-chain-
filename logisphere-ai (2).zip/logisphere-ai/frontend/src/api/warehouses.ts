import { apiClient } from "./client";
import { Warehouse } from "@apptypes/index";

export interface WarehouseWithStats extends Warehouse {
  used_units: number;
  active_shipments: number;
}

export async function fetchWarehouses(): Promise<WarehouseWithStats[]> {
  const { data } = await apiClient.get<WarehouseWithStats[]>("/warehouses");
  return data;
}
