import { Shipment } from "@apptypes/index";

/**
 * World-space layout for one warehouse's Digital Twin scene.
 *
 *   [ Warehouse building ]
 *          |
 *   [ Bay1 Bay2 Bay3 Bay4 ]   <- garage, z = BAY_Z
 *          |
 *      (merge point)          <- z = MERGE_Z, trucks funnel here on dispatch
 *          |
 *        road                 <- runs along +z
 *          |
 *   [ Destination marker ]    <- z = ROAD_LENGTH
 */

export const BAY_SPACING = 2.4;
export const BAY_Z = 2.5;
export const MERGE_Z = 5;
export const ROAD_LENGTH = 20;
export const ROAD_X = 0;

export function getBaySlotPosition(bayIndex: number, totalBays: number): [number, number, number] {
  const offset = bayIndex - (totalBays + 1) / 2;
  return [offset * BAY_SPACING, 0.35, BAY_Z];
}

export const MERGE_POINT: [number, number, number] = [ROAD_X, 0.35, MERGE_Z];
export const DESTINATION_POINT: [number, number, number] = [ROAD_X, 0.35, ROAD_LENGTH];

function lerp3(
  a: [number, number, number],
  b: [number, number, number],
  t: number
): [number, number, number] {
  const clamped = Math.max(0, Math.min(1, t));
  return [
    a[0] + (b[0] - a[0]) * clamped,
    a[1] + (b[1] - a[1]) * clamped,
    a[2] + (b[2] - a[2]) * clamped,
  ];
}

/**
 * Computes the TARGET world position for a shipment's truck given its
 * current status + route_progress. Callers (Truck.tsx) should smoothly
 * lerp their mesh's current position toward this target every frame
 * rather than snapping to it, so backend/status updates never teleport
 * the truck.
 */
export function computeTruckTarget(shipment: Shipment, totalBays: number): [number, number, number] {
  const bayIndex = shipment.assigned_bay ?? 1;
  const bayPos = getBaySlotPosition(bayIndex, totalBays);
  const progress = Math.max(0, Math.min(100, shipment.route_progress ?? 0)) / 100;

  switch (shipment.status) {
    case "pending":
      return bayPos;
    case "dispatched":
      return MERGE_POINT;
    case "in_transit":
    case "delayed":
      return lerp3(MERGE_POINT, DESTINATION_POINT, progress);
    case "delivered":
      return DESTINATION_POINT;
    case "returned":
    case "cancelled":
    default:
      return bayPos;
  }
}

/** 0-1 progress along the road only (for RoutePulse), independent of garage phase. */
export function roadProgress(shipment: Shipment): number {
  if (shipment.status === "delivered") return 1;
  if (shipment.status === "in_transit" || shipment.status === "delayed") {
    return Math.max(0, Math.min(100, shipment.route_progress ?? 0)) / 100;
  }
  return 0;
}
