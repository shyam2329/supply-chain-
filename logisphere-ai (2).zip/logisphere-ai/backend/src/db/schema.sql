-- LogiSphere AI — Core Schema
-- Run automatically on first `docker compose up` via postgres init scripts.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ---------- ENUMS ----------

CREATE TYPE user_role AS ENUM ('admin', 'warehouse_manager', 'supplier');

CREATE TYPE shipment_status AS ENUM (
  'pending',
  'packed',
  'dispatched',
  'in_transit',
  'delayed',
  'delivered',
  'returned',
  'cancelled'
);

CREATE TYPE stock_status AS ENUM ('good', 'low_stock', 'out_of_stock');

-- ---------- USERS ----------

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          user_role NOT NULL DEFAULT 'warehouse_manager',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- WAREHOUSES ----------

CREATE TABLE warehouses (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(120) NOT NULL,
  city          VARCHAR(120) NOT NULL,
  latitude      DOUBLE PRECISION,
  longitude     DOUBLE PRECISION,
  capacity_units INTEGER NOT NULL DEFAULT 0,     -- max storage capacity
  garage_bays   INTEGER NOT NULL DEFAULT 4,       -- number of truck bays for the 3D garage
  manager_id    UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- SUPPLIERS ----------

CREATE TABLE suppliers (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name              VARCHAR(160) NOT NULL,
  contact_email     VARCHAR(160),
  contact_phone     VARCHAR(40),
  user_id           UUID REFERENCES users(id) ON DELETE SET NULL,
  on_time_rate      NUMERIC(5,2) DEFAULT 0,        -- e.g. 95.00 (%)
  performance_score NUMERIC(3,1) DEFAULT 0,        -- e.g. 9.5 out of 10
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- PRODUCTS ----------

CREATE TABLE products (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sku          VARCHAR(60) UNIQUE NOT NULL,
  name         VARCHAR(160) NOT NULL,
  category     VARCHAR(80),
  unit_price   NUMERIC(10,2) DEFAULT 0,
  supplier_id  UUID REFERENCES suppliers(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- INVENTORY (product stock per warehouse) ----------

CREATE TABLE inventory (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id      UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  warehouse_id    UUID NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
  quantity        INTEGER NOT NULL DEFAULT 0,
  low_stock_threshold INTEGER NOT NULL DEFAULT 20,
  status          stock_status NOT NULL DEFAULT 'good',
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (product_id, warehouse_id)
);

-- ---------- INVENTORY TRANSACTIONS (stock in / stock out history) ----------

CREATE TABLE inventory_transactions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  inventory_id  UUID NOT NULL REFERENCES inventory(id) ON DELETE CASCADE,
  change_qty    INTEGER NOT NULL,          -- positive = stock in, negative = stock out
  reason        VARCHAR(120),
  performed_by  UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- SHIPMENTS ----------
-- This table (+ shipment_events) is what drives the 3D Digital Twin.

CREATE TABLE shipments (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reference_code    VARCHAR(30) UNIQUE NOT NULL,        -- e.g. SHP-1024
  origin_warehouse_id      UUID REFERENCES warehouses(id) ON DELETE SET NULL,
  destination_warehouse_id UUID REFERENCES warehouses(id) ON DELETE SET NULL,
  destination_label VARCHAR(160),                       -- for final customer drop points
  product_id        UUID REFERENCES products(id) ON DELETE SET NULL,
  quantity          INTEGER NOT NULL DEFAULT 1,
  status            shipment_status NOT NULL DEFAULT 'pending',
  assigned_bay      INTEGER,                             -- which garage bay the truck occupies
  route_progress    NUMERIC(5,2) NOT NULL DEFAULT 0,      -- 0-100, drives 3D truck position along route
  delay_reason      VARCHAR(255),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- SHIPMENT EVENTS ----------
-- Every status change is logged here AND published to Redis (shipment:events channel)
-- so the frontend can animate the corresponding 3D truck.

CREATE TABLE shipment_events (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shipment_id   UUID NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  status        shipment_status NOT NULL,
  latitude      DOUBLE PRECISION,
  longitude     DOUBLE PRECISION,
  note          VARCHAR(255),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- INDEXES ----------

CREATE INDEX idx_inventory_warehouse ON inventory(warehouse_id);
CREATE INDEX idx_inventory_product ON inventory(product_id);
CREATE INDEX idx_shipments_status ON shipments(status);
CREATE INDEX idx_shipment_events_shipment ON shipment_events(shipment_id);
