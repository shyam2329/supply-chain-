import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Shipment } from "@apptypes/index";
import { computeTruckTarget } from "@three/layout";
import { getFleetHealth, FLEET_HEALTH_ICON } from "@three/fleetHealth";
import HoverInfo from "./HoverInfo";

const STATUS_COLOR: Record<string, string> = {
  pending: "#5B6472",
  dispatched: "#3DDC97",
  in_transit: "#3DDC97",
  delayed: "#FF4D4F",
  delivered: "#4C8DFF",
  returned: "#8A8F98",
  cancelled: "#3A3F47",
};

interface TruckProps {
  shipment: Shipment;
  totalBays: number;
  isSelected: boolean;
  isHovered: boolean;
  onHover: (id: string | null) => void;
  onSelect: (id: string) => void;
}

export default function Truck({
  shipment,
  totalBays,
  isSelected,
  isHovered,
  onHover,
  onSelect,
}: TruckProps) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (!groupRef.current) return;
    const target = computeTruckTarget(shipment, totalBays);
    const targetVec = new THREE.Vector3(...target);

    // Face the direction of travel before moving toward it.
    const current = groupRef.current.position;
    const dz = targetVec.z - current.z;
    if (Math.abs(dz) > 0.01) {
      groupRef.current.rotation.y = dz > 0 ? 0 : Math.PI;
    }

    // Smooth interpolation — this is what prevents teleporting on
    // backend/status updates.
    groupRef.current.position.lerp(targetVec, 0.045);
  });

  const color = STATUS_COLOR[shipment.status] ?? "#5B6472";
  const health = getFleetHealth(shipment.id);
  const isDelayed = shipment.status === "delayed";

  const initial = computeTruckTarget(shipment, totalBays);

  return (
    <group
      ref={groupRef}
      position={initial}
      onPointerOver={(e) => {
        e.stopPropagation();
        onHover(shipment.id);
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        onHover(null);
      }}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(shipment.id);
      }}
    >
      {/* cab */}
      <mesh position={[0, 0.22, 0.35]} castShadow>
        <boxGeometry args={[0.5, 0.4, 0.35]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={isSelected ? 0.6 : 0.15} />
      </mesh>
      {/* trailer */}
      <mesh position={[0, 0.25, -0.15]} castShadow>
        <boxGeometry args={[0.55, 0.45, 0.75]} />
        <meshStandardMaterial color="#1B2130" />
      </mesh>
      {/* selection ring */}
      {isSelected && (
        <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.55, 0.65, 32]} />
          <meshBasicMaterial color="#3DDC97" />
        </mesh>
      )}
      {/* delay warning indicator - not color-only, includes an icon */}
      {isDelayed && (
        <mesh position={[0, 0.75, 0]}>
          <sphereGeometry args={[0.08, 12, 12]} />
          <meshBasicMaterial color="#FF4D4F" />
        </mesh>
      )}

      {isHovered && (
        <HoverInfo>
          <div className="font-semibold text-logisphere-accent">{shipment.reference_code}</div>
          <div>Status: {shipment.status.replace("_", " ")}</div>
          <div>Destination: {shipment.destination_label ?? "—"}</div>
          <div>Qty: {shipment.quantity}</div>
          {isDelayed && shipment.delay_reason && (
            <div className="text-logisphere-danger">⚠ {shipment.delay_reason}</div>
          )}
          <div>
            Fleet: {FLEET_HEALTH_ICON[health]} {health}
          </div>
        </HoverInfo>
      )}
    </group>
  );
}
