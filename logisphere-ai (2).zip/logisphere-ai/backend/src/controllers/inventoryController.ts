import { Response } from "express";
import { pool } from "@config/db";
import { AuthedRequest } from "@middleware/auth";

export async function listInventory(_req: AuthedRequest, res: Response) {
  const result = await pool.query(`
    SELECT
      i.id,
      p.sku,
      p.name AS product_name,
      p.category,
      w.id AS warehouse_id,
      w.name AS warehouse_name,
      i.quantity,
      i.low_stock_threshold,
      i.status,
      i.updated_at
    FROM inventory i
    JOIN products p ON p.id = i.product_id
    JOIN warehouses w ON w.id = i.warehouse_id
    ORDER BY p.name
  `);
  res.json(result.rows);
}

/**
 * Stock in (positive change_qty) / stock out (negative change_qty).
 * Recomputes status (good/low_stock/out_of_stock) from the new quantity
 * vs. the row's low_stock_threshold, and logs the movement.
 */
export async function adjustStock(req: AuthedRequest, res: Response) {
  const { id } = req.params;
  const { change_qty, reason } = req.body as { change_qty: number; reason?: string };

  if (typeof change_qty !== "number" || change_qty === 0) {
    return res.status(400).json({ error: "change_qty must be a non-zero number" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const current = await client.query(
      `SELECT * FROM inventory WHERE id = $1 FOR UPDATE`,
      [id]
    );
    if (current.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Inventory record not found" });
    }

    const row = current.rows[0];
    const newQty = Math.max(0, row.quantity + change_qty);
    const status = newQty === 0 ? "out_of_stock" : newQty <= row.low_stock_threshold ? "low_stock" : "good";

    const updated = await client.query(
      `UPDATE inventory SET quantity = $1, status = $2, updated_at = now() WHERE id = $3 RETURNING *`,
      [newQty, status, id]
    );

    await client.query(
      `INSERT INTO inventory_transactions (inventory_id, change_qty, reason, performed_by)
       VALUES ($1, $2, $3, $4)`,
      [id, change_qty, reason ?? null, req.user?.id ?? null]
    );

    await client.query("COMMIT");
    res.json(updated.rows[0]);
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Stock adjustment failed", err);
    res.status(500).json({ error: "Stock adjustment failed" });
  } finally {
    client.release();
  }
}
