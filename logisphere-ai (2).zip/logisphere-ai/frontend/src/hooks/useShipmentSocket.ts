import { useEffect, useState } from "react";
import { getSocket } from "@services/websocketService";
import { ShipmentUpdateEvent } from "@apptypes/index";

/**
 * Subscribes to the shared Socket.IO connection and surfaces every
 * `shipment:update` event pushed from Redis. Consume `lastEvent` inside
 * the DigitalTwinScene to trigger truck animations (drive out of garage,
 * move along route, stop + flash red on delay, etc).
 */
export function useShipmentSocket() {
  const [lastEvent, setLastEvent] = useState<ShipmentUpdateEvent | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const socket = getSocket();

    const handleConnect = () => setConnected(true);
    const handleDisconnect = () => setConnected(false);
    const handleUpdate = (event: ShipmentUpdateEvent) => setLastEvent(event);

    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);
    socket.on("shipment:update", handleUpdate);
    setConnected(socket.connected);

    return () => {
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
      socket.off("shipment:update", handleUpdate);
    };
  }, []);

  return { connected, lastEvent };
}
