import { apiClient } from "./client";
import { Shipment } from "@apptypes/index";

export type SimulationType =
  | "road_blockage"
  | "bad_weather"
  | "vehicle_breakdown"
  | "warehouse_overload"
  | "supplier_delay";

export interface SimulationResult {
  shipment: Shipment;
  simulation: { type: SimulationType; label: string; delayMinutes: number };
  insight: string;
}

export async function simulateDisruption(
  shipmentId: string,
  type: SimulationType
): Promise<SimulationResult> {
  const { data } = await apiClient.post<SimulationResult>("/simulation/disrupt", {
    shipmentId,
    type,
  });
  return data;
}
