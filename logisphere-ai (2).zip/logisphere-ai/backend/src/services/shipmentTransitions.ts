import { PoolClient } from "pg";

export type ShipmentStatus =
  | "pending"
  | "packed"
  | "dispatched"
  | "in_transit"
  | "delayed"
  | "delivered"
  | "returned"
  | "cancelled";

export const VALID_STATUSES: ShipmentStatus[] = [
  "pending",
  "packed",
  "dispatched",
  "in_transit",
  "delayed",
  "delivered",
  "returned",
  "cancelled",
];

/**
 * Allowed forward transitions per status. `delayed -> in_transit` covers
 * "Continue Journey" after a disruption. `pending`/`packed`/`dispatched`/
 * `in_transit`/`delayed` can all be cancelled. `delivered` and `returned`
 * are terminal except delivered -> returned (the garage-return flow).
 */
export const ALLOWED_TRANSITIONS: Record<ShipmentStatus, ShipmentStatus[]> = {
  pending: ["packed", "dispatched", "cancelled"],
  packed: ["dispatched", "cancelled"],
  dispatched: ["in_transit", "delayed", "cancelled"],
  in_transit: ["delayed", "delivered", "cancelled"],
  delayed: ["in_transit", "delivered", "cancelled"],
  delivered: ["returned"],
  returned: [],
  cancelled: [],
};

export function isTransitionAllowed(from: ShipmentStatus, to: ShipmentStatus): boolean {
  if (from === to) return true; // idempotent no-op updates (e.g. re-sending route_progress) are fine
  return ALLOWED_TRANSITIONS[from]?.includes(to) ?? false;
}

/**
 * Garage bay lifecycle, kept consistent with the DB rather than left to
 * the frontend's display-only bay auto-assignment:
 *  - dispatching a truck releases its bay (assigned_bay -> NULL)
 *  - returning a truck claims the lowest-numbered free bay at its
 *    origin warehouse
 * Must be called inside the same transaction as the status UPDATE.
 */
export async function resolveBayForTransition(
  client: PoolClient,
  toStatus: ShipmentStatus,
  originWarehouseId: string | null
): Promise<number | null | undefined> {
  if (toStatus === "dispatched") {
    return null; // release
  }

  if (toStatus === "returned" && originWarehouseId) {
    const warehouseRes = await client.query(
      `SELECT garage_bays FROM warehouses WHERE id = $1`,
      [originWarehouseId]
    );
    const totalBays: number = warehouseRes.rows[0]?.garage_bays ?? 4;

    const occupiedRes = await client.query(
      `SELECT assigned_bay FROM shipments
       WHERE origin_warehouse_id = $1
         AND status IN ('pending', 'returned')
         AND assigned_bay IS NOT NULL`,
      [originWarehouseId]
    );
    const occupied = new Set(occupiedRes.rows.map((r) => r.assigned_bay));

    for (let bay = 1; bay <= totalBays; bay++) {
      if (!occupied.has(bay)) return bay;
    }
    return null; // garage full — leaves assigned_bay unset rather than erroring the demo
  }

  return undefined; // no change for other transitions
}
