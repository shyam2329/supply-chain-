import { Router } from "express";
import { requireAuth } from "@middleware/auth";
import { asyncHandler } from "@middleware/asyncHandler";
import { getDigitalTwinState } from "@controllers/digitalTwinController";

const router = Router();

router.get("/", requireAuth, asyncHandler(getDigitalTwinState));

export default router;
