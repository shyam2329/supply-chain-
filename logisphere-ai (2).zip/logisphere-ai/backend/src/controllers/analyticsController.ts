import { Response } from "express";
import { pool } from "@config/db";
import { AuthedRequest } from "@middleware/auth";

export async function getAnalytics(_req: AuthedRequest, res: Response) {
  const [
    statusDistribution,
    warehouseUtilization,
    inventoryHealth,
    supplierPerformance,
    eventsOverTime,
  ] = await Promise.all([
    pool.query(`
      SELECT status, COUNT(*)::int AS count
      FROM shipments
      GROUP BY status
      ORDER BY count DESC
    `),
    pool.query(`
      SELECT
        w.name,
        w.capacity_units,
        COALESCE(SUM(i.quantity), 0)::int AS used_units,
        CASE WHEN w.capacity_units > 0
          THEN ROUND((COALESCE(SUM(i.quantity), 0)::numeric / w.capacity_units) * 100, 1)
          ELSE 0
        END AS utilization_pct
      FROM warehouses w
      LEFT JOIN inventory i ON i.warehouse_id = w.id
      GROUP BY w.id, w.name, w.capacity_units
      ORDER BY w.name
    `),
    pool.query(`
      SELECT status, COUNT(*)::int AS count
      FROM inventory
      GROUP BY status
    `),
    pool.query(`
      SELECT name, on_time_rate, performance_score
      FROM suppliers
      ORDER BY performance_score DESC
    `),
    pool.query(`
      SELECT
        DATE_TRUNC('day', created_at)::date AS day,
        status,
        COUNT(*)::int AS count
      FROM shipment_events
      GROUP BY day, status
      ORDER BY day ASC
    `),
  ]);

  res.json({
    shipmentStatusDistribution: statusDistribution.rows,
    warehouseUtilization: warehouseUtilization.rows,
    inventoryHealth: inventoryHealth.rows,
    supplierPerformance: supplierPerformance.rows,
    shipmentEventsOverTime: eventsOverTime.rows,
  });
}
