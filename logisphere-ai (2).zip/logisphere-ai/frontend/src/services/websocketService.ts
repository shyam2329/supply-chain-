import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

/**
 * Returns a shared Socket.IO connection to the backend. Lazily created on
 * first call so it's only opened once a component actually needs live
 * shipment events (e.g. the Digital Twin page), and reused by any other
 * hook/component that needs it afterwards.
 */
export function getSocket(): Socket {
  if (!socket) {
    socket = io(import.meta.env.VITE_SOCKET_URL || "http://localhost:4000", {
      autoConnect: true,
    });
  }
  return socket;
}

export function disconnectSocket() {
  socket?.disconnect();
  socket = null;
}
