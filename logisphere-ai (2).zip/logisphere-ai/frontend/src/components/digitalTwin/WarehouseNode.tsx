import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { WarehouseWithStats } from "@api/warehouses";
import HoverInfo from "./HoverInfo";

interface WarehouseNodeProps {
  warehouse: WarehouseWithStats;
  isHovered: boolean;
  onHover: (id: string | null) => void;
}

export default function WarehouseNode({ warehouse, isHovered, onHover }: WarehouseNodeProps) {
  const ringRef = useRef<THREE.Mesh>(null);
  const capacityPct = warehouse.capacity_units
    ? Math.min(100, Math.round((warehouse.used_units / warehouse.capacity_units) * 100))
    : 0;

  // Heartbeat speed scales with active shipment count; overloaded (>90%
  // capacity) gets a distinct warning colour, not just a faster pulse.
  const activity = warehouse.active_shipments ?? 0;
  const overloaded = capacityPct >= 90;
  const pulseSpeed = 1.2 + activity * 0.6;

  useFrame(({ clock }) => {
    if (!ringRef.current) return;
    const t = clock.getElapsedTime() * pulseSpeed;
    const scale = 1 + Math.abs(Math.sin(t)) * 0.25;
    ringRef.current.scale.set(scale, scale, scale);
    const material = ringRef.current.material as THREE.MeshBasicMaterial;
    material.opacity = 0.5 - Math.abs(Math.sin(t)) * 0.3;
  });

  return (
    <group
      position={[0, 0, -1.5]}
      onPointerOver={(e) => {
        e.stopPropagation();
        onHover(warehouse.id);
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        onHover(null);
      }}
    >
      <mesh position={[0, 0.9, 0]} castShadow>
        <boxGeometry args={[4.5, 1.8, 2]} />
        <meshStandardMaterial color="#161B26" />
      </mesh>
      <mesh position={[0, 1.85, 0]}>
        <boxGeometry args={[4.7, 0.15, 2.2]} />
        <meshStandardMaterial color={overloaded ? "#FF4D4F" : "#3DDC97"} emissive={overloaded ? "#FF4D4F" : "#3DDC97"} emissiveIntensity={0.4} />
      </mesh>

      {/* heartbeat ring on the ground */}
      <mesh ref={ringRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 1.2]}>
        <ringGeometry args={[0.6, 0.75, 40]} />
        <meshBasicMaterial
          color={overloaded ? "#FF4D4F" : "#3DDC97"}
          transparent
          opacity={0.4}
        />
      </mesh>

      {isHovered && (
        <group position={[0, 1.9, 0]}>
          <HoverInfo>
            <div className="font-semibold text-logisphere-accent">{warehouse.name}</div>
            <div>Capacity: {capacityPct}%{overloaded ? " ⚠ overloaded" : ""}</div>
            <div>Garage bays: {warehouse.garage_bays}</div>
            <div>Active shipments: {activity}</div>
          </HoverInfo>
        </group>
      )}
    </group>
  );
}
