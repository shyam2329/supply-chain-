import { Router } from "express";
import { requireAuth } from "@middleware/auth";
import { asyncHandler } from "@middleware/asyncHandler";
import { listSuppliers } from "@controllers/supplierController";

const router = Router();

router.get("/", requireAuth, asyncHandler(listSuppliers));

export default router;
