import { useState } from "react";
import { MERGE_Z, ROAD_LENGTH } from "@three/layout";
import { WarehouseWithStats } from "@api/warehouses";
import HoverInfo from "./HoverInfo";

interface RouteProps {
  warehouse: WarehouseWithStats;
  destinationLabel: string;
  delayedCount: number;
}

export default function Route({ warehouse, destinationLabel, delayedCount }: RouteProps) {
  const [hovered, setHovered] = useState(false);
  const length = ROAD_LENGTH - MERGE_Z;
  const centerZ = MERGE_Z + length / 2;
  const distanceKm = Math.round(length * 8); // purely illustrative scale
  const riskLevel = delayedCount > 0 ? "High" : "Low";

  return (
    <group
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        setHovered(false);
      }}
    >
      <mesh position={[0, 0.02, centerZ]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[1.4, length]} />
        <meshStandardMaterial color="#12161F" />
      </mesh>
      {/* lane marking */}
      <mesh position={[0, 0.025, centerZ]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.05, length]} />
        <meshStandardMaterial color="#2A3240" />
      </mesh>

      {hovered && (
        <group position={[0.9, 0.4, centerZ]}>
          <HoverInfo>
            <div className="font-semibold text-logisphere-accent">Route</div>
            <div>Origin: {warehouse.name}</div>
            <div>Destination: {destinationLabel}</div>
            <div>Distance: ~{distanceKm} km</div>
            <div className={riskLevel === "High" ? "text-logisphere-danger" : ""}>
              Delay risk: {riskLevel}
            </div>
          </HoverInfo>
        </group>
      )}
    </group>
  );
}
