import { Router } from "express";
import { requireAuth, requireRole } from "@middleware/auth";
import { asyncHandler } from "@middleware/asyncHandler";
import {
  listShipments,
  getShipmentTimeline,
  updateShipmentStatus,
} from "@controllers/shipmentController";

const router = Router();

router.get("/", requireAuth, asyncHandler(listShipments));
router.get("/:id/timeline", requireAuth, asyncHandler(getShipmentTimeline));
router.patch(
  "/:id/status",
  requireAuth,
  requireRole("admin", "warehouse_manager"),
  asyncHandler(updateShipmentStatus)
);

export default router;
