import { useEffect, useState } from "react";
import { fetchWarehouses, WarehouseWithStats } from "@api/warehouses";

export default function Warehouses() {
  const [warehouses, setWarehouses] = useState<WarehouseWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchWarehouses()
      .then(setWarehouses)
      .catch(() => setError("Failed to load warehouses."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Warehouses</h1>

      {loading && <p className="text-sm text-gray-500">Loading warehouses...</p>}
      {error && <p className="text-sm text-logisphere-danger">{error}</p>}
      {!loading && !error && warehouses.length === 0 && (
        <p className="text-sm text-gray-500">No warehouses yet.</p>
      )}

      {!loading && !error && warehouses.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {warehouses.map((w) => {
            const capacityPct = w.capacity_units
              ? Math.min(100, Math.round((w.used_units / w.capacity_units) * 100))
              : 0;
            const overloaded = capacityPct >= 90;
            const availableBays = Math.max(0, w.garage_bays - w.active_shipments);

            return (
              <div
                key={w.id}
                className="bg-logisphere-panel border border-white/10 rounded-xl p-4 space-y-3"
              >
                <div>
                  <div className="font-semibold">{w.name}</div>
                  <div className="text-xs text-gray-500">{w.city}</div>
                </div>

                <div>
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Capacity</span>
                    <span className={overloaded ? "text-logisphere-danger" : ""}>
                      {capacityPct}%{overloaded ? " ⚠" : ""}
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className={`h-full ${overloaded ? "bg-logisphere-danger" : "bg-logisphere-accent"}`}
                      style={{ width: `${capacityPct}%` }}
                    />
                  </div>
                  <div className="text-xs text-gray-600 mt-1">
                    {w.used_units.toLocaleString()} / {w.capacity_units.toLocaleString()} units
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-white/5 rounded-md px-2 py-1.5">
                    <div className="text-gray-500">Garage bays</div>
                    <div className="font-semibold">{w.garage_bays}</div>
                  </div>
                  <div className="bg-white/5 rounded-md px-2 py-1.5">
                    <div className="text-gray-500">Available bays</div>
                    <div className="font-semibold">{availableBays}</div>
                  </div>
                  <div className="bg-white/5 rounded-md px-2 py-1.5 col-span-2">
                    <div className="text-gray-500">Active shipments</div>
                    <div className="font-semibold">{w.active_shipments}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
