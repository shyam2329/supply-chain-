/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        logisphere: {
          bg: "#0B0F19",
          panel: "#121826",
          accent: "#3DDC97",
          warn: "#FFB020",
          danger: "#FF4D4F",
        },
      },
    },
  },
  plugins: [],
};
