import { apiClient } from "./client";

export interface DashboardSummary {
  totalShipments: number;
  activeShipments: number;
  delayedShipments: number;
  warehouseCapacity: number;
  fleetAvailability: number;
  supplierPerformance: number;
  deliveryPerformance: string;
  aiInsights: string[];
}

export async function fetchDashboardSummary(): Promise<DashboardSummary> {
  const { data } = await apiClient.get<DashboardSummary>("/dashboard/summary");
  return data;
}
